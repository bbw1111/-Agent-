import uuid
import json
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, List, Optional
from database.db import (
    save_analysis_record,
    save_tool_call_log,
    save_chart_record,
    save_report_record,
    update_analysis_record,
    get_tool_call_logs,
    get_charts_by_trace,
    get_reports_by_trace
)
import config


class TraceLogger:
    def __init__(self):
        self.current_trace_id = None
        self.user_question = None
        self.analysis_plan = None
        self.risk_level = 'low'
        self.tool_calls = []
        self.start_time = None
        self.steps = []
        self.pending_review = None

    def start_trace(self, user_question: str, analysis_plan: str = None, risk_level: str = 'low') -> str:
        self.current_trace_id = str(uuid.uuid4())[:16]
        self.user_question = user_question
        self.analysis_plan = analysis_plan
        self.risk_level = risk_level
        self.start_time = time.time()
        self.tool_calls = []
        self.steps = []
        self.pending_review = None

        save_analysis_record(
            trace_id=self.current_trace_id,
            user_question=user_question,
            analysis_plan=analysis_plan,
            risk_level=risk_level,
            status='in_progress'
        )

        self._save_trace_to_file()

        return self.current_trace_id

    def add_step(self, step_data: Dict[str, Any]) -> None:
        step_index = len(self.steps)

        step_record = {
            'step_index': step_index,
            'trace_id': self.current_trace_id,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3],
            'thought': step_data.get('thought', ''),
            'action': step_data.get('action', ''),
            'action_input': step_data.get('action_input', {}),
            'observation': step_data.get('observation', ''),
            'risk_level': step_data.get('risk_level', 'low'),
            'need_human_review': step_data.get('need_human_review', False),
            'status': step_data.get('status', 'completed'),
            'error_message': step_data.get('error_message', ''),
            'duration_ms': step_data.get('duration_ms', 0),
            'human_review_approved': step_data.get('human_review_approved', None),
            'human_review_reason': step_data.get('human_review_reason', '')
        }

        self.steps.append(step_record)

        self._save_trace_to_file()

    def log_tool_call(self, tool_name: str, tool_input: Dict, tool_output: Any = None,
                     tool_output_summary: str = None, duration_ms: int = None,
                     risk_level: str = 'low') -> None:
        if not self.current_trace_id:
            return

        self.tool_calls.append({
            'tool_name': tool_name,
            'tool_input': tool_input,
            'tool_output': tool_output,
            'tool_output_summary': tool_output_summary,
            'duration_ms': duration_ms,
            'risk_level': risk_level
        })

        save_tool_call_log(
            trace_id=self.current_trace_id,
            tool_name=tool_name,
            tool_input=tool_input,
            tool_output=tool_output,
            tool_output_summary=tool_output_summary,
            duration_ms=duration_ms,
            risk_level=risk_level
        )

    def log_chart(self, chart_type: str, chart_title: str, chart_path: str,
                  chart_data_summary: str = None) -> None:
        if not self.current_trace_id:
            return

        save_chart_record(
            trace_id=self.current_trace_id,
            chart_type=chart_type,
            chart_title=chart_title,
            chart_path=chart_path,
            chart_data_summary=chart_data_summary
        )

    def log_report(self, report_type: str, report_path: str = None,
                   report_content: str = None, risk_level: str = 'low',
                   approved: bool = False) -> None:
        if not self.current_trace_id:
            return

        save_report_record(
            trace_id=self.current_trace_id,
            report_type=report_type,
            report_path=report_path,
            report_content=report_content,
            risk_level=risk_level,
            approved=approved
        )

    def set_pending_review(self, action: str, action_input: Dict, risk_reason: str) -> None:
        self.pending_review = {
            'action': action,
            'action_input': action_input,
            'risk_reason': risk_reason,
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }

    def clear_pending_review(self) -> None:
        self.pending_review = None

    def approve_review(self, reason: str = '') -> None:
        if self.pending_review and self.steps:
            last_step = self.steps[-1]
            last_step['human_review_approved'] = True
            last_step['human_review_reason'] = reason
            last_step['status'] = 'completed'

        self._save_trace_to_file()
        self.clear_pending_review()

    def reject_review(self, reason: str = '') -> None:
        if self.pending_review and self.steps:
            last_step = self.steps[-1]
            last_step['human_review_approved'] = False
            last_step['human_review_reason'] = reason
            last_step['status'] = 'skipped'

        self._save_trace_to_file()
        self.clear_pending_review()

    def end_trace(self, status: str = 'completed') -> None:
        if not self.current_trace_id:
            return

        completed_at = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        update_analysis_record(
            trace_id=self.current_trace_id,
            status=status,
            completed_at=completed_at
        )

        trace_summary = self.get_trace_summary()
        trace_summary['end_status'] = status
        trace_summary['completed_at'] = completed_at

        self._save_trace_to_file()

        self.current_trace_id = None
        self.user_question = None
        self.analysis_plan = None
        self.risk_level = 'low'
        self.tool_calls = []
        self.start_time = None
        self.steps = []
        self.pending_review = None

    def get_trace_summary(self) -> Optional[Dict[str, Any]]:
        if not self.current_trace_id:
            return None

        total_duration = 0
        if self.start_time:
            total_duration = int((time.time() - self.start_time) * 1000)

        approved_steps = sum(1 for s in self.steps if s.get('human_review_approved') is True)
        rejected_steps = sum(1 for s in self.steps if s.get('human_review_approved') is False)
        pending_steps = sum(1 for s in self.steps if s.get('need_human_review') and s.get('human_review_approved') is None)

        return {
            'trace_id': self.current_trace_id,
            'user_question': self.user_question,
            'analysis_plan': self.analysis_plan,
            'risk_level': self.risk_level,
            'step_count': len(self.steps),
            'approved_steps': approved_steps,
            'rejected_steps': rejected_steps,
            'pending_review': pending_steps,
            'total_duration_ms': total_duration,
            'tool_call_count': len(self.tool_calls),
            'steps': self.steps,
            'pending_review_item': self.pending_review
        }

    def get_trace_details(self, trace_id: str = None) -> Optional[Dict[str, Any]]:
        trace_id = trace_id or self.current_trace_id
        if not trace_id:
            return None

        tool_logs = get_tool_call_logs(trace_id)
        charts = get_charts_by_trace(trace_id)
        reports = get_reports_by_trace(trace_id)

        return {
            'trace_id': trace_id,
            'tool_logs': tool_logs,
            'charts': charts,
            'reports': reports,
            'steps': self.steps if self.current_trace_id == trace_id else []
        }

    def _save_trace_to_file(self) -> None:
        if not self.current_trace_id:
            return

        try:
            trace_file = config.TRACE_LOGS_DIR / f"{self.current_trace_id}.jsonl"

            trace_data = {
                'trace_id': self.current_trace_id,
                'user_question': self.user_question,
                'analysis_plan': self.analysis_plan,
                'risk_level': self.risk_level,
                'steps': self.steps,
                'pending_review': self.pending_review,
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }

            with open(trace_file, 'a', encoding='utf-8') as f:
                f.write(json.dumps(trace_data, ensure_ascii=False) + '\n')

        except Exception as e:
            pass

    def get_react_steps_display(self) -> List[Dict[str, Any]]:
        return [
            {
                'step': i + 1,
                'thought': step.get('thought', ''),
                'action': step.get('action', ''),
                'action_input': step.get('action_input', {}),
                'observation': str(step.get('observation', ''))[:200],
                'status': step.get('status', ''),
                'need_review': step.get('need_human_review', False),
                'approved': step.get('human_review_approved'),
                'duration_ms': step.get('duration_ms', 0)
            }
            for i, step in enumerate(self.steps)
        ]
