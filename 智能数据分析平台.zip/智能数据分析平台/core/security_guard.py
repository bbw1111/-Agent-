import re
import json
from typing import Dict, Any, List, Tuple, Optional
import config


class SecurityGuard:
    def __init__(self):
        self.dangerous_patterns = config.DANGEROUS_PATTERNS
        self.high_risk_patterns = config.HIGH_RISK_PATTERNS
        self.allowed_tools = config.ALLOWED_TOOLS

    def check_dangerous_input(self, user_input: str) -> Tuple[bool, str]:
        if not user_input:
            return False, "输入不能为空"

        user_input_lower = user_input.lower()

        for pattern in self.dangerous_patterns:
            if pattern.lower() in user_input_lower:
                return False, f"检测到危险指令: {pattern}，请修改输入后重试"

        if re.search(r'os\.system|subprocess|Popen|spawn', user_input, re.IGNORECASE):
            return False, "检测到系统命令执行指令，已被拦截"

        if re.search(r'open\s*\(', user_input, re.IGNORECASE):
            return False, "检测到文件操作指令，请使用上传功能代替"

        if re.search(r'__import__|getattr|setattr|delattr', user_input):
            return False, "检测到动态代码执行指令，已被拦截"

        return True, "输入检查通过"

    def check_action_security(self, action: str, action_input: Dict[str, Any]) -> Tuple[bool, str, str]:
        if action not in self.allowed_tools and action != "final_answer":
            return False, f"工具 {action} 不在白名单中", "high"

        action_str = json.dumps(action_input, ensure_ascii=False)
        action_str_lower = action_str.lower()

        for pattern in self.dangerous_patterns:
            if pattern.lower() in action_str_lower:
                risk_reason = f"检测到危险内容: {pattern}"
                return False, risk_reason, "high"

        for pattern in self.high_risk_patterns:
            if pattern.lower() in action_str_lower:
                risk_reason = f"检测到高风险关键词: {pattern}"
                return True, risk_reason, "medium"

        return True, "安全检查通过", "low"

    def check_tool_call(self, tool_name: str) -> Tuple[bool, str]:
        if tool_name not in self.allowed_tools and tool_name != "final_answer":
            return False, f"工具 {tool_name} 不在白名单中，仅允许调用系统提供的分析工具"
        return True, "工具检查通过"

    def check_field_access(self, field_name: str, allowed_fields: List[str] = None) -> Tuple[bool, Any]:
        if not field_name:
            return False, "字段名不能为空"

        field_lower = str(field_name).lower()

        sensitive_keywords = ['password', 'passwd', 'secret', 'key', 'token', 'auth', 'credential']
        if any(kw in field_lower for kw in sensitive_keywords):
            return True, {'risk_level': 'high', 'warning': f'字段 "{field_name}" 可能包含敏感信息，请确认是否继续访问'}

        if allowed_fields and field_name not in allowed_fields:
            return False, f"字段 '{field_name}' 不在数据集中"

        return True, "字段检查通过"

    def check_data_volume(self, row_count: int, threshold: int = 100000) -> Tuple[bool, Optional[Dict]]:
        if row_count > threshold:
            return True, {'risk_level': 'medium', 'warning': f'数据量较大 ({row_count} 行)，处理可能需要较长时间'}
        return False, None

    def check_operation_risk(self, operation: str, params: Dict[str, Any]) -> Tuple[str, Optional[Dict]]:
        risk_indicators = []

        if '全量' in str(operation) or '所有' in str(operation):
            risk_indicators.append('high')

        if '导出' in str(operation) or '下载' in str(operation):
            risk_indicators.append('medium')

        params_str = json.dumps(params, ensure_ascii=False).lower()
        if any(kw in params_str for kw in self.high_risk_patterns):
            risk_indicators.append('high')

        if not risk_indicators:
            return 'low', None

        highest_risk = 'high' if 'high' in risk_indicators else 'medium'

        warning_messages = {
            'high': '此操作风险较高，需要人工确认',
            'medium': '此操作涉及数据操作，请确认'
        }

        return highest_risk, {'risk_level': highest_risk, 'warning': warning_messages.get(highest_risk)}

    def check_analysis_request(self, user_question: str, available_fields: List[str]) -> Tuple[bool, Any, str, Optional[List[str]]]:
        warnings = []
        risk_level = 'low'

        check_result, check_msg = self.check_dangerous_input(user_question)
        if not check_result:
            return False, check_msg, 'high', None

        question_lower = user_question.lower()

        if any(kw in question_lower for kw in self.high_risk_patterns):
            risk_level = 'medium'
            warnings.append('检测到敏感操作关键词，请确保操作合规')

        field_mentioned = False
        for field in available_fields:
            if field.lower() in question_lower:
                field_mentioned = True
                break

        if not field_mentioned and any(kw in question_lower for kw in ['统计', '分析', '计算', '查找']):
            warnings.append(f'问题中未明确指定字段，系统将自动选择相关字段进行分析')

        return True, warnings if warnings else "分析请求检查通过", risk_level, None

    def sanitize_output(self, output: Any) -> Any:
        if output is None:
            return None

        output_str = str(output)

        sensitive_patterns = [
            (r'password["\']?\s*[:=]\s*["\'][^"\']+["\']', 'password: ****'),
            (r'secret["\']?\s*[:=]\s*["\'][^"\']+["\']', 'secret: ****'),
            (r'token["\']?\s*[:=]\s*["\'][^"\']+["\']', 'token: ****'),
            (r'api[_-]?key["\']?\s*[:=]\s*["\'][^"\']+["\']', 'api_key: ****'),
        ]

        for pattern, replacement in sensitive_patterns:
            output_str = re.sub(pattern, replacement, output_str, flags=re.IGNORECASE)

        return output_str

    def validate_json_action(self, action_dict: Dict[str, Any]) -> Tuple[bool, str, Dict[str, Any]]:
        required_fields = ['thought', 'action', 'action_input']
        for field in required_fields:
            if field not in action_dict:
                return False, f"缺少必需字段: {field}", {}

        action = action_dict.get('action', '')
        action_input = action_dict.get('action_input', {})

        if not isinstance(action_input, dict):
            return False, "action_input 必须是字典格式", {}

        return True, "JSON格式验证通过", action_dict

    def detect_human_review_needed(self, action: str, action_input: Dict[str, Any]) -> bool:
        is_safe, risk_reason, risk_level = self.check_action_security(action, action_input)

        if not is_safe:
            return True

        if risk_level in ['medium', 'high']:
            return True

        action_str = json.dumps(action_input, ensure_ascii=False).lower()
        for pattern in self.high_risk_patterns:
            if pattern.lower() in action_str:
                return True

        return False
