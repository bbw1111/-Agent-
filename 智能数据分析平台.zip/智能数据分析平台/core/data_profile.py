import pandas as pd
import numpy as np
from datetime import datetime

class DataProfiler:
    def __init__(self, df):
        self.df = df

    def generate_profile(self):
        if self.df is None or self.df.empty:
            return None

        profile = {
            'basic_info': self._get_basic_info(),
            'column_types': self._classify_columns(),
            'numeric_summary': self._get_numeric_summary(),
            'categorical_summary': self._get_categorical_summary(),
            'missing_analysis': self._get_missing_analysis(),
            'date_summary': self._get_date_summary()
        }
        return profile

    def _get_basic_info(self):
        return {
            'total_rows': len(self.df),
            'total_columns': len(self.df.columns),
            'memory_usage': round(self.df.memory_usage(deep=True).sum() / 1024 / 1024, 2),
            'complete_rows': len(self.df.dropna()),
            'duplicate_rows': self.df.duplicated().sum()
        }

    def _classify_columns(self):
        classification = {
            'numeric': [],
            'categorical': [],
            'date': [],
            'other': []
        }

        for col in self.df.columns:
            col_type = str(self.df[col].dtype)

            if any(dt in col_type for dt in ['int64', 'float64', 'int32', 'float32']):
                classification['numeric'].append(col)
            elif any(dt in col_type for dt in ['datetime', 'date']):
                classification['date'].append(col)
            elif self.df[col].nunique() < len(self.df) * 0.5 and self.df[col].nunique() < 100:
                classification['categorical'].append(col)
            else:
                classification['other'].append(col)

        return classification

    def _get_numeric_summary(self):
        numeric_cols = self._classify_columns()['numeric']
        if not numeric_cols:
            return None

        summary = {}
        for col in numeric_cols:
            series = self.df[col].dropna()
            if len(series) == 0:
                continue

            summary[col] = {
                'count': int(len(series)),
                'mean': round(float(series.mean()), 2),
                'std': round(float(series.std()), 2),
                'min': round(float(series.min()), 2),
                'max': round(float(series.max()), 2),
                'q25': round(float(series.quantile(0.25)), 2),
                'q50': round(float(series.quantile(0.50)), 2),
                'q75': round(float(series.quantile(0.75)), 2),
                'sum': round(float(series.sum()), 2)
            }
        return summary

    def _get_categorical_summary(self):
        categorical_cols = self._classify_columns()['categorical']
        if not categorical_cols:
            return None

        summary = {}
        for col in categorical_cols:
            value_counts = self.df[col].value_counts().head(10)
            summary[col] = {
                'unique_count': int(self.df[col].nunique()),
                'top_values': {str(k): int(v) for k, v in value_counts.items()},
                'most_common': str(value_counts.index[0]) if len(value_counts) > 0 else None,
                'most_common_count': int(value_counts.iloc[0]) if len(value_counts) > 0 else 0
            }
        return summary

    def _get_missing_analysis(self):
        missing_info = {}
        for col in self.df.columns:
            missing_count = self.df[col].isnull().sum()
            if missing_count > 0:
                missing_info[col] = {
                    'missing_count': int(missing_count),
                    'missing_rate': round(missing_count / len(self.df) * 100, 2),
                    'data_type': str(self.df[col].dtype)
                }
        return missing_info if missing_info else None

    def _get_date_summary(self):
        date_cols = self._classify_columns()['date']
        if not date_cols:
            return None

        summary = {}
        for col in date_cols:
            dates = pd.to_datetime(self.df[col], errors='coerce').dropna()
            if len(dates) == 0:
                continue

            summary[col] = {
                'count': int(len(dates)),
                'min_date': dates.min().strftime('%Y-%m-%d') if hasattr(dates.min(), 'strftime') else str(dates.min()),
                'max_date': dates.max().strftime('%Y-%m-%d') if hasattr(dates.max(), 'strftime') else str(dates.max()),
                'date_range_days': int((dates.max() - dates.min()).days) if hasattr(dates.max(), '__sub__') else 0,
                'unique_count': int(dates.nunique())
            }
        return summary

    def suggest_analysis(self):
        suggestions = []
        classification = self._classify_columns()

        if classification['numeric']:
            suggestions.append({
                'type': 'descriptive',
                'description': '描述性统计分析',
                'fields': classification['numeric'][:3]
            })

            if len(classification['numeric']) >= 2:
                suggestions.append({
                    'type': 'correlation',
                    'description': '字段相关性分析',
                    'fields': classification['numeric'][:2]
                })

        if classification['categorical']:
            for cat_col in classification['categorical'][:2]:
                if classification['numeric']:
                    suggestions.append({
                        'type': 'groupby',
                        'description': f'按{cat_col}分组统计',
                        'group_field': cat_col,
                        'value_field': classification['numeric'][0]
                    })

        if classification['date']:
            suggestions.append({
                'type': 'trend',
                'description': '时间序列趋势分析',
                'date_field': classification['date'][0]
            })

        return suggestions
