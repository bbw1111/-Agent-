import json
import re
from typing import Optional, Dict, Any, List

class LLMClientBase:
    def __init__(self, api_key: str = None, model: str = None):
        self.api_key = api_key
        self.model = model

    def generate(self, prompt: str, system_prompt: Optional[str] = None) -> str:
        raise NotImplementedError

    def chat(self, messages: List[Dict[str, str]], **kwargs) -> str:
        raise NotImplementedError


class TongyiClient(LLMClientBase):
    def __init__(self, api_key: str = None, model: str = "qwen-turbo"):
        super().__init__(api_key, model)
        if not api_key:
            api_key = self._get_api_key_from_env()
        self.api_key = api_key
        self.model = model

    def _get_api_key_from_env(self) -> Optional[str]:
        import os
        env_vars = [
            "DASHSCOPE_API_KEY",
            "TONGYI_API_KEY",
            "OPENAI_API_KEY",
            "API_KEY"
        ]
        for var in env_vars:
            api_key = os.environ.get(var)
            if api_key:
                return api_key

        try:
            from dotenv import load_dotenv
            from pathlib import Path
            env_file = Path(__file__).parent.parent / ".env"
            if env_file.exists():
                load_dotenv(env_file, override=False)
                for var in env_vars:
                    api_key = os.environ.get(var)
                    if api_key:
                        return api_key
        except ImportError:
            pass

        return None

    def generate(self, prompt: str, system_prompt: Optional[str] = None) -> str:
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        return self.chat(messages)

    def chat(self, messages: List[Dict[str, str]], **kwargs) -> str:
        try:
            import dashscope
            from dashscope import Generation

            dashscope.api_key = self.api_key

            response = Generation.call(
                model=self.model,
                messages=messages,
                result_format='message',
                **kwargs
            )

            if response.status_code == 200:
                return response.output.choices[0].message.content
            else:
                error_msg = response.message if hasattr(response, 'message') else str(response)
                raise Exception(f"通义千问API调用失败: {error_msg}")

        except ImportError:
            raise ImportError("请安装 dashscope: pip install dashscope")
        except Exception as e:
            raise Exception(f"通义千问API调用异常: {str(e)}")


class OpenAICompatibleClient(LLMClientBase):
    def __init__(self, api_key: str = None, model: str = "gpt-4", base_url: str = "https://api.openai.com/v1"):
        super().__init__(api_key, model)
        self.api_key = api_key
        self.model = model
        self.base_url = base_url.rstrip('/')

    def generate(self, prompt: str, system_prompt: Optional[str] = None) -> str:
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        return self.chat(messages)

    def chat(self, messages: List[Dict[str, str]], **kwargs) -> str:
        try:
            import openai
            client = openai.OpenAI(api_key=self.api_key, base_url=self.base_url)

            response = client.chat.completions.create(
                model=self.model,
                messages=messages,
                **kwargs
            )

            return response.choices[0].message.content

        except ImportError:
            raise ImportError("请安装 openai: pip install openai")
        except Exception as e:
            raise Exception(f"OpenAI API调用异常: {str(e)}")


class LocalLLMClient(LLMClientBase):
    def __init__(self, model: str = "local-model", base_url: str = "http://localhost:11434/v1", api_key: str = "dummy"):
        super().__init__(api_key, model)
        self.model = model
        self.base_url = base_url

    def generate(self, prompt: str, system_prompt: Optional[str] = None) -> str:
        messages = []
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        messages.append({"role": "user", "content": prompt})
        return self.chat(messages)

    def chat(self, messages: List[Dict[str, str]], **kwargs) -> str:
        try:
            import openai
            client = openai.OpenAI(api_key=self.api_key, base_url=self.base_url)

            response = client.chat.completions.create(
                model=self.model,
                messages=messages,
                **kwargs
            )

            return response.choices[0].message.content

        except Exception as e:
            raise Exception(f"本地LLM调用异常: {str(e)}")


def create_llm_client(provider: str = "tongyi", **kwargs) -> LLMClientBase:
    providers = {
        "tongyi": TongyiClient,
        "qwen": TongyiClient,
        "openai": OpenAICompatibleClient,
        "local": LocalLLMClient
    }

    client_class = providers.get(provider.lower())
    if not client_class:
        raise ValueError(f"不支持的LLM提供商: {provider}")

    return client_class(**kwargs)
