import pandas as pd
import numpy as np
from datetime import datetime, timedelta

class AnalysisEngine:
    def __init__(self, df=None):
        self.df = df

    def set_data(self, df):
        self.df = df

    def get_descriptive_stats(self, columns=None):
        if self.df is None:
            return None

        if columns:
            cols_to_analyze = [c for c in columns if c in self.df.columns]
            if not cols_to_analyze:
                return None
            return self.df[cols_to_analyze].describe()
        else:
            numeric_cols = self.df.select_dtypes(include=[np.number]).columns
            return self.df[numeric_cols].describe()

    def groupby_sum(self, group_col, value_col):
        if self.df is None:
            return None

        if group_col not in self.df.columns or value_col not in self.df.columns:
            return None

        try:
            result = self.df.groupby(group_col)[value_col].sum().reset_index()
            result.columns = [group_col, f'{value_col}_sum']
            return result
        except:
            return None

    def groupby_count(self, group_col, value_col):
        if self.df is None:
            return None

        if group_col not in self.df.columns or value_col not in self.df.columns:
            return None

        try:
            result = self.df.groupby(group_col)[value_col].count().reset_index()
            result.columns = [group_col, f'{value_col}_count']
            return result
        except:
            return None

    def groupby_mean(self, group_col, value_col):
        if self.df is None:
            return None

        if group_col not in self.df.columns or value_col not in self.df.columns:
            return None

        try:
            result = self.df.groupby(group_col)[value_col].mean().reset_index()
            result.columns = [group_col, f'{value_col}_mean']
            return result
        except:
            return None

    def topn_analysis(self, value_col, n=10, group_col=None):
        if self.df is None:
            return None

        if value_col not in self.df.columns:
            return None

        try:
            if group_col and group_col in self.df.columns:
                result = self.df.groupby(group_col)[value_col].sum().sort_values(ascending=False).head(n).reset_index()
                result.columns = [group_col, value_col]
            else:
                if self.df[value_col].dtype == 'object':
                    result = self.df[value_col].value_counts().head(n).reset_index()
                    result.columns = [value_col, 'count']
                else:
                    result = self.df.nlargest(n, value_col).reset_index(drop=True)
            return result
        except:
            return None

    def trend_analysis(self, date_col, value_col, freq='M'):
        if self.df is None:
            return None

        if date_col not in self.df.columns or value_col not in self.df.columns:
            return None

        try:
            df_copy = self.df.copy()
            df_copy[date_col] = pd.to_datetime(df_copy[date_col], errors='coerce')
            df_copy = df_copy.dropna(subset=[date_col, value_col])

            if df_copy.empty:
                return None

            df_copy = df_copy.sort_values(date_col)
            df_copy.set_index(date_col, inplace=True)

            freq_map = {
                'D': '每天',
                'W': '每周',
                'M': '每月',
                'Q': '每季度',
                'Y': '每年'
            }

            resampled = df_copy[value_col].resample(freq).sum().reset_index()
            resampled.columns = [date_col, value_col]

            trend_info = self._detect_trend(resampled[value_col])

            return {
                'data': resampled,
                'trend': trend_info,
                'freq': freq_map.get(freq, freq)
            }
        except:
            return None

    def _detect_trend(self, series):
        if len(series) < 2:
            return '数据点不足'

        first_half = series.iloc[:len(series)//2].mean()
        second_half = series.iloc[len(series)//2:].mean()

        change_ratio = (second_half - first_half) / first_half * 100 if first_half != 0 else 0

        if change_ratio > 10:
            return f'上升趋势 (增幅: {change_ratio:.1f}%)'
        elif change_ratio < -10:
            return f'下降趋势 (降幅: {abs(change_ratio):.1f}%)'
        else:
            return '基本持平'

    def filter_data(self, conditions):
        if self.df is None:
            return None

        try:
            df_filtered = self.df.copy()

            for col, op, value in conditions:
                if col not in df_filtered.columns:
                    continue

                if op == '==':
                    df_filtered = df_filtered[df_filtered[col] == value]
                elif op == '!=':
                    df_filtered = df_filtered[df_filtered[col] != value]
                elif op == '>':
                    df_filtered = df_filtered[df_filtered[col] > value]
                elif op == '>=':
                    df_filtered = df_filtered[df_filtered[col] >= value]
                elif op == '<':
                    df_filtered = df_filtered[df_filtered[col] < value]
                elif op == '<=':
                    df_filtered = df_filtered[df_filtered[col] <= value]
                elif op == 'contains':
                    df_filtered = df_filtered[df_filtered[col].astype(str).str.contains(str(value), na=False)]
                elif op == 'startswith':
                    df_filtered = df_filtered[df_filtered[col].astype(str).str.startswith(str(value), na=False)]

            return df_filtered
        except:
            return None

    def sort_data(self, columns, ascending=True):
        if self.df is None:
            return None

        try:
            valid_cols = [c for c in columns if c in self.df.columns]
            if not valid_cols:
                return None
            return self.df.sort_values(by=valid_cols, ascending=ascending)
        except:
            return None

    def correlation_analysis(self, col1, col2):
        if self.df is None:
            return None

        if col1 not in self.df.columns or col2 not in self.df.columns:
            return None

        try:
            numeric_df = self.df[[col1, col2]].dropna()
            if len(numeric_df) < 3:
                return {'correlation': None, 'interpretation': '数据点不足'}

            corr = numeric_df[col1].corr(numeric_df[col2])

            if abs(corr) >= 0.8:
                interpretation = '强相关'
            elif abs(corr) >= 0.5:
                interpretation = '中等相关'
            elif abs(corr) >= 0.3:
                interpretation = '弱相关'
            else:
                interpretation = '几乎不相关'

            if corr > 0:
                interpretation = '正' + interpretation
            else:
                interpretation = '负' + interpretation

            return {
                'correlation': round(corr, 4),
                'interpretation': interpretation,
                'data_points': len(numeric_df)
            }
        except:
            return None

    def outlier_detection(self, column, method='iqr'):
        if self.df is None:
            return None

        if column not in self.df.columns:
            return None

        try:
            series = self.df[column].dropna()

            if method == 'iqr':
                q1 = series.quantile(0.25)
                q3 = series.quantile(0.75)
                iqr = q3 - q1
                lower_bound = q1 - 1.5 * iqr
                upper_bound = q3 + 1.5 * iqr

                outliers = self.df[(self.df[column] < lower_bound) | (self.df[column] > upper_bound)]

                return {
                    'method': 'IQR',
                    'lower_bound': round(lower_bound, 2),
                    'upper_bound': round(upper_bound, 2),
                    'outlier_count': len(outliers),
                    'outliers': outliers
                }
            elif method == 'zscore':
                z_scores = np.abs((series - series.mean()) / series.std())
                outlier_indices = z_scores[z_scores > 3].index
                outliers = self.df.loc[outlier_indices]

                return {
                    'method': 'Z-Score',
                    'threshold': 3,
                    'outlier_count': len(outliers),
                    'outliers': outliers
                }

        except:
            return None
