import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
import config

class DataLoader:
    def __init__(self):
        self.df = None
        self.file_name = None
        self.file_path = None
        self.file_size = None
        self.load_time = None

    def load_file(self, uploaded_file):
        self.file_name = uploaded_file.name
        self.file_size = uploaded_file.size
        self.load_time = datetime.now()

        file_extension = Path(self.file_name).suffix.lower()

        try:
            if file_extension == '.csv':
                self.df = self._load_csv(uploaded_file)
            elif file_extension in ['.xlsx', '.xls']:
                self.df = self._load_excel(uploaded_file)
            else:
                raise ValueError(f"不支持的文件格式: {file_extension}，仅支持 CSV 和 Excel 文件")

            if self.df is None or self.df.empty:
                raise ValueError("文件为空或无法读取数据")

            return self.df

        except UnicodeDecodeError:
            for encoding in ['utf-8', 'gbk', 'gb2312', 'utf-16', 'latin1']:
                try:
                    uploaded_file.seek(0)
                    self.df = pd.read_csv(uploaded_file, encoding=encoding)
                    return self.df
                except:
                    continue
            raise ValueError("文件编码错误，请确保文件为 UTF-8 或 GBK 编码")

        except Exception as e:
            raise ValueError(f"文件读取失败: {str(e)}")

    def _load_csv(self, uploaded_file):
        encodings = ['utf-8-sig', 'utf-8', 'gbk', 'gb2312', 'gb18030', 'latin1']
        for encoding in encodings:
            try:
                uploaded_file.seek(0)
                df = pd.read_csv(uploaded_file, encoding=encoding)
                df.columns = [str(c).strip().replace('\ufeff', '') for c in df.columns]
                return df
            except UnicodeDecodeError:
                continue
            except Exception as e:
                if 'empty' in str(e).lower():
                    return pd.DataFrame()
                raise
        raise ValueError("CSV文件编码不受支持")

    def _load_excel(self, uploaded_file):
        try:
            uploaded_file.seek(0)
            return pd.read_excel(uploaded_file, engine='openpyxl')
        except:
            try:
                uploaded_file.seek(0)
                return pd.read_excel(uploaded_file, engine='xlrd')
            except:
                raise ValueError("Excel文件读取失败，请确保文件格式正确")

    def get_preview(self, rows=20):
        if self.df is None:
            return None
        return self.df.head(rows)

    def get_basic_info(self):
        if self.df is None:
            return None
        return {
            'row_count': len(self.df),
            'column_count': len(self.df.columns),
            'file_name': self.file_name,
            'file_size': self.file_size,
            'load_time': self.load_time.strftime('%Y-%m-%d %H:%M:%S')
        }

    def get_columns_info(self):
        if self.df is None:
            return None
        columns_info = []
        for col in self.df.columns:
            col_type = str(self.df[col].dtype)
            missing_count = self.df[col].isnull().sum()
            unique_count = self.df[col].nunique()
            columns_info.append({
                'name': col,
                'type': col_type,
                'missing_count': int(missing_count),
                'missing_rate': round(missing_count / len(self.df) * 100, 2) if len(self.df) > 0 else 0,
                'unique_count': int(unique_count)
            })
        return columns_info

    def validate_file(self, uploaded_file):
        if uploaded_file is None:
            return False, "未上传文件"

        file_name = uploaded_file.name
        file_extension = Path(file_name).suffix.lower()

        if file_extension not in ['.csv', '.xlsx', '.xls']:
            return False, f"不支持的文件格式: {file_extension}，仅支持 CSV 和 Excel 文件"

        if uploaded_file.size == 0:
            return False, "文件为空，请上传有效的文件"

        max_size = 100 * 1024 * 1024
        if uploaded_file.size > max_size:
            return False, f"文件过大，请上传小于 100MB 的文件"

        return True, "文件验证通过"
