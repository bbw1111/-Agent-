import pandas as pd
from pathlib import Path
from datetime import datetime
import config

class ReportGenerator:
    def __init__(self, df=None):
        self.df = df

    def set_data(self, df):
        self.df = df

    def generate_markdown_report(self, analysis_data, trace_id):
        config.REPORTS_DIR.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        report_filename = f"report_{trace_id}_{timestamp}.md"
        report_path = config.REPORTS_DIR / report_filename

        report_content = self._build_markdown_content(analysis_data, trace_id)

        with open(report_path, 'w', encoding='utf-8') as f:
            f.write(report_content)

        return str(report_path), report_content

    def generate_word_report(self, analysis_data, trace_id):
        try:
            from docx import Document
            from docx.shared import Inches, Pt
            from docx.enum.text import WD_ALIGN_PARAGRAPH
        except ImportError:
            return None, "请安装 python-docx 库以生成 Word 报告"

        config.REPORTS_DIR.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        report_filename = f"report_{trace_id}_{timestamp}.docx"
        report_path = config.REPORTS_DIR / report_filename

        doc = Document()

        doc.add_heading('智能数据分析报告', 0)
        doc.add_paragraph(f'Trace ID: {trace_id}')
        doc.add_paragraph(f'生成时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}')

        if 'basic_info' in analysis_data:
            doc.add_heading('一、数据基本信息', level=1)
            basic_info = analysis_data['basic_info']
            for key, value in basic_info.items():
                doc.add_paragraph(f'{key}: {value}')

        if 'user_question' in analysis_data:
            doc.add_heading('二、分析需求', level=1)
            doc.add_paragraph(analysis_data['user_question'])

        if 'analysis_plan' in analysis_data:
            doc.add_heading('三、分析计划', level=1)
            doc.add_paragraph(analysis_data['analysis_plan'])

        if 'analysis_results' in analysis_data:
            doc.add_heading('四、分析结果', level=1)
            results = analysis_data['analysis_results']
            if isinstance(results, pd.DataFrame):
                doc.add_paragraph('分析结果数据：')
                for idx, row in results.head(20).iterrows():
                    doc.add_paragraph(str(row.to_dict()))
            else:
                doc.add_paragraph(str(results))

        if 'chart_paths' in analysis_data:
            doc.add_heading('五、图表信息', level=1)
            for chart_info in analysis_data['chart_paths']:
                doc.add_paragraph(f"图表类型: {chart_info.get('type', 'N/A')}")
                doc.add_paragraph(f"图表路径: {chart_info.get('path', 'N/A')}")
                doc.add_paragraph(f"图表标题: {chart_info.get('title', 'N/A')}")

        if 'conclusions' in analysis_data:
            doc.add_heading('六、分析结论', level=1)
            conclusions = analysis_data['conclusions']
            if isinstance(conclusions, list):
                for conclusion in conclusions:
                    doc.add_paragraph(conclusion)
            else:
                doc.add_paragraph(conclusions)

        doc.save(report_path)

        return str(report_path), "Word报告生成成功"

    def _build_markdown_content(self, analysis_data, trace_id):
        template = config.REPORT_TEMPLATES['markdown']

        basic_info_str = self._format_basic_info(analysis_data.get('basic_info', {}))
        analysis_plan_str = analysis_data.get('analysis_plan', '未指定分析计划')
        analysis_results_str = self._format_analysis_results(analysis_data.get('analysis_results'))

        chart_info_list = analysis_data.get('chart_paths', [])
        chart_info_str = "\n".join([
            f"- **类型**: {c.get('type', 'N/A')} | **标题**: {c.get('title', 'N/A')} | **路径**: {c.get('path', 'N/A')}"
            for c in chart_info_list
        ]) if chart_info_list else "暂无图表"

        conclusions = analysis_data.get('conclusions', [])
        if isinstance(conclusions, list):
            conclusions_str = "\n".join([f"- {c}" for c in conclusions])
        else:
            conclusions_str = str(conclusions)

        react_steps_str = analysis_data.get('react_steps', '本次分析未记录详细Agent执行步骤。')

        content = template.format(
            title=analysis_data.get('title', '智能数据分析报告'),
            basic_info=basic_info_str,
            analysis_requirement=analysis_data.get('user_question', '未指定'),
            analysis_plan=analysis_plan_str,
            analysis_results=analysis_results_str,
            chart_info=chart_info_str,
            conclusions=conclusions_str,
            trace_id=trace_id,
            generated_time=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            react_steps=react_steps_str
        )

        return content

    def _format_basic_info(self, basic_info):
        if not basic_info:
            return "暂无数据基本信息"

        lines = []
        for key, value in basic_info.items():
            key_display = {
                'row_count': '数据行数',
                'column_count': '数据列数',
                'file_name': '文件名',
                'file_size': '文件大小',
                'load_time': '加载时间',
                'numeric_columns': '数值字段',
                'categorical_columns': '类别字段',
                'date_columns': '日期字段'
            }.get(key, key)
            lines.append(f"- **{key_display}**: {value}")

        return "\n".join(lines)

    def _format_analysis_results(self, results):
        if results is None:
            return "暂无分析结果"

        if isinstance(results, pd.DataFrame):
            return f"\n\n数据预览（前20行）：\n\n" + results.head(20).to_markdown()

        if isinstance(results, dict):
            lines = []
            for key, value in results.items():
                lines.append(f"- **{key}**: {value}")
            return "\n".join(lines)

        return str(results)

    def generate_conclusion(self, analysis_data, chart_generator=None):
        conclusions = []

        if 'user_question' in analysis_data:
            conclusions.append(f"**分析目标**: {analysis_data['user_question']}")

        if 'basic_info' in analysis_data and 'fields_used' in analysis_data:
            conclusions.append(f"**使用字段**: {', '.join(analysis_data['fields_used'])}")

        results = analysis_data.get('analysis_results')

        if isinstance(results, pd.DataFrame) and not results.empty:
            numeric_cols = results.select_dtypes(include=['number']).columns
            if len(numeric_cols) > 0:
                for col in numeric_cols:
                    max_val = results[col].max()
                    min_val = results[col].min()
                    max_idx = results[col].idxmax()
                    min_idx = results[col].idxmin()

                    if 'x' in results.columns:
                        max_item = results.loc[max_idx, 'x']
                        min_item = results.loc[min_idx, 'x']
                        conclusions.append(f"**最高值**: {max_item} ({col}: {max_val:.2f})")
                        conclusions.append(f"**最低值**: {min_item} ({col}: {min_val:.2f})")
                    else:
                        conclusions.append(f"**最高值**: {col} = {max_val:.2f}")
                        conclusions.append(f"**最低值**: {col} = {min_val:.2f}")

        if 'trend' in analysis_data:
            conclusions.append(f"**趋势分析**: {analysis_data['trend']}")

        if 'chart_paths' in analysis_data and analysis_data['chart_paths']:
            chart_types = [c.get('type', '未知') for c in analysis_data['chart_paths']]
            conclusions.append(f"**生成图表**: {', '.join(chart_types)}")

        suggestions = self._generate_suggestions(analysis_data)
        if suggestions:
            conclusions.append(f"**建议**: {suggestions}")

        return conclusions

    def _generate_suggestions(self, analysis_data):
        suggestions = []

        if 'missing_analysis' in analysis_data:
            missing = analysis_data['missing_analysis']
            if missing:
                suggestions.append("数据存在缺失值，建议进行数据清洗或缺失值处理。")

        results = analysis_data.get('analysis_results')
        if isinstance(results, pd.DataFrame):
            if len(results) > 50:
                suggestions.append("数据量较大，建议关注异常值和离群点。")

            numeric_cols = results.select_dtypes(include=['number']).columns
            if len(numeric_cols) >= 2:
                suggestions.append("可考虑进行多变量相关性分析，探索字段间关系。")

        if not suggestions:
            suggestions.append("数据质量良好，建议持续监控数据变化趋势。")

        return " ".join(suggestions)
