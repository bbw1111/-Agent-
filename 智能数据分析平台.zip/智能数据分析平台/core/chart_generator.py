import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from pathlib import Path
from datetime import datetime
import config

plt.rcParams['font.sans-serif'] = config.CHINESE_FONT_CANDIDATES
plt.rcParams['axes.unicode_minus'] = False

class ChartGenerator:
    def __init__(self, df=None):
        self.df = df
        self.generated_charts = []

    def set_data(self, df):
        self.df = df

    def generate_chart(self, chart_type, data, title=None, x_label=None, y_label=None, trace_id=None):
        if self.df is None:
            return None, "数据未加载"

        config.CHARTS_DIR.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        chart_filename = f"{trace_id}_{chart_type}_{timestamp}.png" if trace_id else f"{chart_type}_{timestamp}.png"
        chart_path = config.CHARTS_DIR / chart_filename

        try:
            fig, ax = plt.subplots(figsize=(10, 6))

            if chart_type == 'bar':
                self._generate_bar_chart(ax, data, title, x_label, y_label)
            elif chart_type == 'line':
                self._generate_line_chart(ax, data, title, x_label, y_label)
            elif chart_type == 'pie':
                self._generate_pie_chart(ax, data, title)
            elif chart_type == 'scatter':
                self._generate_scatter_chart(ax, data, title, x_label, y_label)
            elif chart_type == 'histogram':
                self._generate_histogram(ax, data, title, x_label, y_label)
            else:
                return None, f"不支持的图表类型: {chart_type}"

            plt.tight_layout()
            fig.savefig(chart_path, dpi=150, bbox_inches='tight')
            plt.close(fig)

            self.generated_charts.append({
                'path': str(chart_path),
                'type': chart_type,
                'title': title
            })

            return str(chart_path), "图表生成成功"

        except Exception as e:
            return None, f"图表生成失败: {str(e)}"

    def _generate_bar_chart(self, ax, data, title, x_label, y_label):
        if isinstance(data, pd.DataFrame):
            if 'x' in data.columns and 'y' in data.columns:
                x, y = data['x'], data['y']
            else:
                x, y = data.iloc[:, 0], data.iloc[:, 1]
        else:
            x, y = data

        colors = config.CHART_COLORS[:len(x)]
        bars = ax.bar(x, y, color=colors, edgecolor='white', linewidth=0.7)

        for bar in bars:
            height = bar.get_height()
            ax.text(bar.get_x() + bar.get_width()/2., height,
                   f'{height:.0f}',
                   ha='center', va='bottom', fontsize=9)

        ax.set_title(title or '柱状图', fontsize=14, fontweight='bold', pad=15)
        ax.set_xlabel(x_label or '类别', fontsize=11)
        ax.set_ylabel(y_label or '数值', fontsize=11)
        ax.tick_params(axis='x', rotation=45)
        ax.grid(axis='y', alpha=0.3, linestyle='--')

    def _generate_line_chart(self, ax, data, title, x_label, y_label):
        if isinstance(data, pd.DataFrame):
            if 'x' in data.columns and 'y' in data.columns:
                x, y = data['x'], data['y']
            else:
                x, y = data.iloc[:, 0], data.iloc[:, 1]
        else:
            x, y = data

        ax.plot(x, y, marker='o', markersize=6, linewidth=2,
                color=config.CHART_COLORS[0], markerfacecolor=config.CHART_COLORS[1])

        for i, (xi, yi) in enumerate(zip(x, y)):
            if i % max(1, len(x)//10) == 0:
                ax.annotate(f'{yi:.0f}', (xi, yi), textcoords="offset points",
                           xytext=(0, 10), ha='center', fontsize=8)

        ax.set_title(title or '折线图', fontsize=14, fontweight='bold', pad=15)
        ax.set_xlabel(x_label or 'X轴', fontsize=11)
        ax.set_ylabel(y_label or 'Y轴', fontsize=11)
        ax.grid(alpha=0.3, linestyle='--')
        ax.tick_params(axis='x', rotation=45)

    def _generate_pie_chart(self, ax, data, title):
        if isinstance(data, pd.DataFrame):
            if 'label' in data.columns and 'value' in data.columns:
                labels, values = data['label'], data['value']
            else:
                labels, values = data.iloc[:, 0], data.iloc[:, 1]
        else:
            labels, values = data

        colors = config.CHART_COLORS[:len(labels)]

        wedges, texts, autotexts = ax.pie(
            values,
            labels=labels,
            colors=colors,
            autopct='%1.1f%%',
            startangle=90,
            pctdistance=0.75,
            explode=[0.02] * len(labels)
        )

        for autotext in autotexts:
            autotext.set_fontsize(9)
            autotext.set_fontweight('bold')

        ax.set_title(title or '饼图', fontsize=14, fontweight='bold', pad=15)

    def _generate_scatter_chart(self, ax, data, title, x_label, y_label):
        if isinstance(data, pd.DataFrame):
            if 'x' in data.columns and 'y' in data.columns:
                x, y = data['x'], data['y']
            else:
                x, y = data.iloc[:, 0], data.iloc[:, 1]
        else:
            x, y = data

        ax.scatter(x, y, c=config.CHART_COLORS[0], alpha=0.6, s=50, edgecolors='white', linewidth=0.5)

        z = np.polyfit(x, y, 1)
        p = np.poly1d(z)
        ax.plot(x, sorted(x), p(x), "--", color=config.CHART_COLORS[1], alpha=0.8, linewidth=2)

        ax.set_title(title or '散点图', fontsize=14, fontweight='bold', pad=15)
        ax.set_xlabel(x_label or 'X轴', fontsize=11)
        ax.set_ylabel(y_label or 'Y轴', fontsize=11)
        ax.grid(alpha=0.3, linestyle='--')

    def _generate_histogram(self, ax, data, title, x_label, y_label):
        if isinstance(data, pd.DataFrame):
            values = data.iloc[:, 0]
        else:
            values = data

        n, bins, patches = ax.hist(values, bins=20, color=config.CHART_COLORS[0],
                                    edgecolor='white', linewidth=0.7, alpha=0.8)

        for i, patch in enumerate(patches):
            if i % 2 == 0:
                patch.set_facecolor(config.CHART_COLORS[1])

        ax.set_title(title or '直方图', fontsize=14, fontweight='bold', pad=15)
        ax.set_xlabel(x_label or '数值', fontsize=11)
        ax.set_ylabel(y_label or '频数', fontsize=11)
        ax.grid(axis='y', alpha=0.3, linestyle='--')

    def prepare_groupby_data(self, group_col, value_col, agg_func='sum'):
        if self.df is None:
            return None

        try:
            if agg_func == 'sum':
                result = self.df.groupby(group_col)[value_col].sum()
            elif agg_func == 'count':
                result = self.df.groupby(group_col)[value_col].count()
            elif agg_func == 'mean':
                result = self.df.groupby(group_col)[value_col].mean()
            elif agg_func == 'avg':
                result = self.df.groupby(group_col)[value_col].mean()
            elif agg_func == 'max':
                result = self.df.groupby(group_col)[value_col].max()
            elif agg_func == 'min':
                result = self.df.groupby(group_col)[value_col].min()
            else:
                result = self.df.groupby(group_col)[value_col].sum()

            df_result = pd.DataFrame({
                'x': result.index.astype(str),
                'y': result.values
            })
            return df_result

        except Exception as e:
            return None

    def prepare_topn_data(self, value_col, n=10, group_col=None):
        if self.df is None:
            return None

        try:
            if group_col:
                result = self.df.groupby(group_col)[value_col].sum().sort_values(ascending=False).head(n)
            else:
                result = self.df[value_col].value_counts().head(n) if self.df[value_col].dtype == 'object' else self.df.nlargest(n, value_col)[value_col]

            df_result = pd.DataFrame({
                'x': result.index.astype(str),
                'y': result.values
            })
            return df_result

        except Exception as e:
            return None

    def prepare_trend_data(self, date_col, value_col):
        if self.df is None:
            return None

        try:
            df_copy = self.df.copy()
            df_copy[date_col] = pd.to_datetime(df_copy[date_col], errors='coerce')
            df_copy = df_copy.dropna(subset=[date_col])
            df_copy = df_copy.sort_values(date_col)

            result = df_copy.groupby(date_col)[value_col].sum()

            df_result = pd.DataFrame({
                'x': result.index.astype(str),
                'y': result.values
            })
            return df_result

        except Exception as e:
            return None

    def prepare_pie_data(self, group_col, value_col, top_n=8):
        if self.df is None:
            return None

        try:
            result = self.df.groupby(group_col)[value_col].sum().sort_values(ascending=False)

            if len(result) > top_n:
                other_sum = result.iloc[top_n:].sum()
                result = result.iloc[:top_n]
                result['其他'] = other_sum

            df_result = pd.DataFrame({
                'label': result.index.astype(str),
                'value': result.values
            })
            return df_result

        except Exception as e:
            return None
