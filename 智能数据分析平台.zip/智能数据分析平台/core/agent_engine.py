import pandas as pd
import re
import json
import time
from typing import Dict, Any, List, Optional, Tuple
from datetime import datetime

import config
from core.analysis_engine import AnalysisEngine
from core.chart_generator import ChartGenerator
from core.report_generator import ReportGenerator
from core.security_guard import SecurityGuard
from core.trace_logger import TraceLogger
from core.llm_client import create_llm_client
from core.data_profile import DataProfiler
from tools.pandas_tools import create_pandas_tools
from tools.chart_tools import create_chart_tools
from tools.report_tools import create_report_tools


class AgentEngine:
    def __init__(self, df=None, llm_provider='qwen', llm_config=None):
        self.df = df
        self.analysis_engine = AnalysisEngine(df)
        self.chart_generator = ChartGenerator(df)
        self.report_generator = ReportGenerator(df)
        self.security_guard = SecurityGuard()
        self.trace_logger = TraceLogger()

        self.llm_provider = llm_provider
        self.llm_config = llm_config or {}
        self.llm_client = None

        self.tool_registry = {}
        self.current_trace_id = None
        self.fields_info = None
        self.observation_history = []
        self.pending_review_action = None

        self._update_fields_info()
        self._init_tool_registry()

    def set_data(self, df):
        self.df = df
        self.analysis_engine.set_data(df)
        self.chart_generator.set_data(df)
        self.report_generator.set_data(df)
        self._update_fields_info()
        self._init_tool_registry()

    def _update_fields_info(self):
        if self.df is None:
            return

        self.fields_info = {
            'columns': list(self.df.columns),
            'dtypes': {col: str(dtype) for col, dtype in self.df.dtypes.items()},
            'numeric_columns': list(self.df.select_dtypes(include=['number']).columns),
            'categorical_columns': list(self.df.select_dtypes(include=['object', 'category']).columns),
            'date_columns': list(self.df.select_dtypes(include=['datetime']).columns)
        }

    def _init_tool_registry(self):
        pandas_tools = create_pandas_tools(self.df, self.analysis_engine)
        chart_tools = create_chart_tools(self.df, self.chart_generator)
        report_tools = create_report_tools(self.df, self.report_generator, self.current_trace_id)

        self.tool_registry = {}
        for tool_name, tool_info in pandas_tools.items():
            self.tool_registry[tool_name] = tool_info
        for tool_name, tool_info in chart_tools.items():
            self.tool_registry[tool_name] = tool_info
        for tool_name, tool_info in report_tools.items():
            self.tool_registry[tool_name] = tool_info

    def _init_llm_client(self):
        try:
            provider_config = config.LLM_PROVIDERS.get(self.llm_provider, {})
            env_key = provider_config.get('env_key')

            api_key = self.llm_config.get('api_key')
            if not api_key and env_key:
                import os
                api_key = os.environ.get(env_key)
                print(f"[DEBUG] 从环境变量获取 API Key: {env_key} = {api_key[:10] if api_key else 'None'}...")

            if not api_key:
                print("[DEBUG] API Key 为空，设置 llm_client = None")
                self.llm_client = None
                return False

            model = self.llm_config.get('model') or provider_config.get('default_model', 'qwen-turbo')
            print(f"[DEBUG] 创建 LLM Client: provider={self.llm_provider}, model={model}")

            self.llm_client = create_llm_client(
                provider=self.llm_provider,
                api_key=api_key,
                model=model
            )
            return True

        except Exception as e:
            print(f"[DEBUG] 初始化 LLM Client 失败: {e}")
            self.llm_client = None
            return False

    def _build_tool_descriptions(self) -> str:
        lines = []
        for tool_name, tool_info in self.tool_registry.items():
            schema = tool_info.get('args_schema', {})
            props = schema.get('properties', {})
            required = schema.get('required', [])

            args_str = ', '.join([f"{k}({'必填' if k in required else '可选'})" for k in props.keys()])

            lines.append(f"- {tool_name}: {tool_info.get('description', '')}")
            if args_str:
                lines.append(f"  参数: {args_str}")

        return '\n'.join(lines)

    def _robust_json_parse(self, text: str) -> Tuple[bool, Dict]:
        if not text:
            return False, config.REACT_FALLBACK_PLAN

        text = text.strip()

        try:
            return True, json.loads(text)
        except json.JSONDecodeError:
            pass

        json_block_match = re.search(r'```(?:json)?\s*([\s\S]+?)\s*```', text)
        if json_block_match:
            try:
                return True, json.loads(json_block_match.group(1).strip())
            except json.JSONDecodeError:
                pass

        brace_match = re.search(r'\{[\s\S]*\}', text)
        if brace_match:
            try:
                json_str = brace_match.group()
                json_str = json_str.replace('「', '"').replace('」', '"')
                json_str = json_str.replace('『', '"').replace('』', '"')
                json_str = re.sub(r',(\s*[}\]])', r'\1', json_str)
                return True, json.loads(json_str)
            except json.JSONDecodeError:
                pass

        try:
            text = text.replace("'", '"')
            text = re.sub(r',\s*([}\]])', r'\1', text)
            return True, json.loads(text)
        except json.JSONDecodeError:
            pass

        return False, config.REACT_FALLBACK_PLAN

    def _generate_llm_prompt(self, user_question: str, max_steps: int = 5) -> str:
        tool_descriptions = self._build_tool_descriptions()

        previous_steps = ""
        if self.observation_history:
            previous_steps = "\n\n## 之前的分析步骤和结果：\n"
            for i, (obs_thought, obs_result) in enumerate(self.observation_history, 1):
                previous_steps += f"\n步骤 {i}:\n思维: {obs_thought}\n结果: {obs_result}\n"

        prompt = config.SYSTEM_PROMPTS['react_agent'].format(
            tool_descriptions=tool_descriptions,
            columns=', '.join(self.fields_info.get('columns', [])),
            numeric_columns=', '.join(self.fields_info.get('numeric_columns', [])),
            categorical_columns=', '.join(self.fields_info.get('categorical_columns', [])),
            date_columns=', '.join(self.fields_info.get('date_columns', []))
        )

        prompt += f"\n\n## 用户问题：\n{user_question}"
        prompt += previous_steps
        prompt += f"\n\n注意：你已经执行了 {len(self.observation_history)} 步，最多可以执行 {max_steps} 步。"

        return prompt

    def _call_llm(self, prompt: str) -> Optional[str]:
        if self.llm_client is None:
            if not self._init_llm_client():
                return None

        try:
            system_prompt = "你是一个数据分析Agent，遵循ReAct模式工作。始终返回JSON格式的结果。"
            response = self.llm_client.generate(
                prompt=prompt,
                system_prompt=system_prompt
            )
            return response
        except Exception as e:
            return None

    def _execute_tool(self, action: str, action_input: Dict) -> Dict[str, Any]:
        if action == 'final_answer':
            return {'type': 'final', 'result': action_input.get('answer', '')}

        if action not in self.tool_registry:
            return {'type': 'error', 'error': f'未知工具: {action}'}

        tool_info = self.tool_registry[action]
        tool_callable = tool_info.get('callable')

        if not tool_callable:
            return {'type': 'error', 'error': f'工具 {action} 不可调用'}

        try:
            result = tool_callable(action_input)
            return {'type': 'success', 'result': result}
        except Exception as e:
            return {'type': 'error', 'error': str(e)}

    def _check_and_handle_review(self, action: str, action_input: Dict) -> Tuple[bool, Optional[Dict]]:
        need_review = self.security_guard.detect_human_review_needed(action, action_input)

        if not need_review:
            return False, None

        is_safe, risk_reason, risk_level = self.security_guard.check_action_security(action, action_input)

        if not is_safe:
            return True, {
                'need_review': True,
                'risk_level': 'high',
                'risk_reason': risk_reason,
                'action': action,
                'action_input': action_input,
                'auto_reject': True
            }

        return True, {
            'need_review': True,
            'risk_level': risk_level,
            'risk_reason': risk_reason,
            'action': action,
            'action_input': action_input,
            'auto_reject': False
        }

    def run_react_agent(self, query: str, max_steps: int = None, chart_type: str = 'auto') -> Dict[str, Any]:
        if self.df is None:
            return {
                'success': False,
                'error': '数据未加载',
                'final_answer': '',
                'charts': [],
                'report_path': '',
                'trace_id': '',
                'steps': []
            }

        max_steps = max_steps or config.AGENT_MAX_STEPS

        self.current_trace_id = self.trace_logger.start_trace(
            user_question=query,
            analysis_plan='ReAct推理分析',
            risk_level='low'
        )

        self.observation_history = []
        generated_charts = []
        report_path = None
        last_result_data = None
        last_action = None

        for step in range(max_steps):
            step_start_time = time.time()

            parsed_action = config.REACT_FALLBACK_PLAN.copy()

            if step == 0:
                parsed_action = {
                    "thought": "首先需要了解数据的基本结构和字段信息",
                    "action": "data_profile",
                    "action_input": {},
                    "need_human_review": False
                }
            else:
                llm_response = self._call_llm(self._generate_llm_prompt(query, max_steps))

                if llm_response is None:
                    parsed_action = config.REACT_FALLBACK_PLAN.copy()
                    parsed_action['thought'] = "LLM调用失败或未配置API Key，使用默认数据画像分析。"
                else:
                    parse_success, parsed_result = self._robust_json_parse(llm_response)
                    if parse_success and isinstance(parsed_result, dict):
                        parsed_action = parsed_result
                    else:
                        parsed_action = config.REACT_FALLBACK_PLAN.copy()
                        parsed_action['thought'] = f"无法解析LLM输出，使用默认分析。"

            thought = parsed_action.get('thought', '')
            action = parsed_action.get('action', 'data_profile')
            action_input = parsed_action.get('action_input', {}) or {}

            need_review, review_info = self._check_and_handle_review(action, action_input)

            step_duration_ms = int((time.time() - step_start_time) * 1000)

            if need_review and review_info.get('auto_reject'):
                self.trace_logger.add_step({
                    'thought': thought,
                    'action': action,
                    'action_input': action_input,
                    'observation': f'安全审核未通过: {review_info.get("risk_reason")}',
                    'risk_level': 'high',
                    'need_human_review': True,
                    'status': 'rejected',
                    'duration_ms': step_duration_ms,
                    'human_review_approved': False,
                    'human_review_reason': review_info.get('risk_reason')
                })
                continue

            if need_review and not review_info.get('auto_reject'):
                self.pending_review_action = review_info
                self.trace_logger.set_pending_review(
                    action=action,
                    action_input=action_input,
                    risk_reason=review_info.get('risk_reason', '')
                )
                self.trace_logger.add_step({
                    'thought': thought,
                    'action': action,
                    'action_input': action_input,
                    'observation': f'等待人工审核: {review_info.get("risk_reason")}',
                    'risk_level': review_info.get('risk_level', 'medium'),
                    'need_human_review': True,
                    'status': 'pending_review',
                    'duration_ms': step_duration_ms
                })
                return {
                    'success': True,
                    'need_human_review': True,
                    'review_info': review_info,
                    'pending_step': len(self.observation_history),
                    'trace_id': self.current_trace_id,
                    'final_answer': '',
                    'charts': [],
                    'report_path': '',
                    'steps': self.trace_logger.get_react_steps_display()
                }

            tool_result = self._execute_tool(action, action_input)

            step_duration_ms = int((time.time() - step_start_time) * 1000)

            if tool_result.get('type') == 'final':
                final_answer = tool_result.get('result', '')
                self.trace_logger.add_step({
                    'thought': thought,
                    'action': 'final_answer',
                    'action_input': action_input,
                    'observation': final_answer,
                    'risk_level': 'low',
                    'need_human_review': False,
                    'status': 'completed',
                    'duration_ms': step_duration_ms
                })
                self.trace_logger.end_trace(status='completed')
                return {
                    'success': True,
                    'need_human_review': False,
                    'final_answer': final_answer,
                    'charts': generated_charts,
                    'report_path': report_path or '',
                    'trace_id': self.current_trace_id,
                    'steps': self.trace_logger.get_react_steps_display()
                }

            if tool_result.get('type') == 'error':
                observation = f"执行错误: {tool_result.get('error')}"
            else:
                result_data = tool_result.get('result', {})
                last_result_data = result_data
                last_action = action
                if isinstance(result_data, dict):
                    observation = result_data.get('summary', str(result_data.get('data', ''))[:200])
                    if 'chart_path' in result_data and result_data['chart_path']:
                        generated_charts.append({
                            'path': result_data['chart_path'],
                            'type': result_data.get('chart_type', 'unknown')
                        })
                    if 'report_path' in result_data and result_data['report_path']:
                        report_path = result_data['report_path']
                else:
                    observation = str(result_data)[:200]

            self.observation_history.append((thought, observation))

            self.trace_logger.add_step({
                'thought': thought,
                'action': action,
                'action_input': action_input,
                'observation': observation,
                'risk_level': 'low',
                'need_human_review': False,
                'status': 'completed',
                'duration_ms': step_duration_ms
            })

            self.trace_logger.log_tool_call(
                tool_name=action,
                tool_input=action_input,
                tool_output=tool_result,
                tool_output_summary=observation[:500],
                duration_ms=step_duration_ms
            )

        self.trace_logger.end_trace(status='max_steps_reached')

        final_answer, data_table = self._generate_conclusion_from_data(
            query, last_result_data, last_action, self.observation_history
        )

        return self._build_unified_result(
            task_type="data_analysis",
            trace_id=self.current_trace_id,
            user_question=query,
            final_answer=final_answer,
            summary=final_answer[:200] + "..." if len(final_answer) > 200 else final_answer,
            data_table=data_table,
            charts=generated_charts,
            steps=self.trace_logger.get_react_steps_display(),
            tool_results={"last_result": last_result_data},
            status="success"
        )

    def continue_after_review(self, approved: bool, reason: str = '') -> Dict[str, Any]:
        if not self.pending_review_action:
            return {
                'success': False,
                'error': '没有待审核的操作'
            }

        action = self.pending_review_action.get('action')
        action_input = self.pending_review_action.get('action_input', {})

        if approved:
            self.trace_logger.approve_review(reason)
            tool_result = self._execute_tool(action, action_input)

            step_start_time = time.time()

            if tool_result.get('type') == 'final':
                final_answer = tool_result.get('result', '')
                self.trace_logger.add_step({
                    'thought': '人工审核通过，继续执行',
                    'action': 'final_answer',
                    'action_input': {},
                    'observation': final_answer,
                    'risk_level': 'low',
                    'need_human_review': False,
                    'status': 'completed',
                    'duration_ms': int((time.time() - step_start_time) * 1000)
                })
                self.trace_logger.end_trace(status='completed')
                return {
                    'success': True,
                    'final_answer': final_answer,
                    'charts': [],
                    'report_path': '',
                    'trace_id': self.current_trace_id,
                    'steps': self.trace_logger.get_react_steps_display()
                }

            result_data = tool_result.get('result', {})
            observation = str(result_data) if result_data else '执行完成'

            self.observation_history.append(('人工审核通过，继续执行', observation))

            self.pending_review_action = None

            return {
                'success': True,
                'need_human_review': False,
                'observation': observation,
                'pending_step': len(self.observation_history),
                'trace_id': self.current_trace_id,
                'steps': self.trace_logger.get_react_steps_display()
            }
        else:
            self.trace_logger.reject_review(reason)
            self.pending_review_action = None
            return {
                'success': False,
                'error': f'人工审核拒绝: {reason}',
                'trace_id': self.current_trace_id,
                'steps': self.trace_logger.get_react_steps_display()
            }

    def classify_question(self, question: str) -> str:
        if self.df is None:
            chat_keywords = [
                "你是谁", "你好", "早上好", "下午好", "晚上好", "嗨", "嘿",
                "介绍一下", "解释一下", "什么是", "什么叫",
                "帮我写", "项目介绍", "系统介绍", "怎么样", "如何", "怎么",
                "星期", "今天", "明天", "昨天", "天气", "时间", "日期", "月份",
                "多少", "为什么", "原因", "怎么办", "干啥", "做啥",
                "叫什么", "名字", "是谁", "有用吗", "靠谱吗",
                "笑话", "幽默", "搞笑", "故事", "新闻", "八卦",
                "电影", "音乐", "游戏", "体育", "足球", "篮球",
                "美食", "旅游", "健康", "减肥", "健身",
                "股票", "基金", "理财", "加密货币", "比特币",
                "翻译", "英文", "英语", "学英语", "学编程",
                "写代码", "写诗", "写作文", "帮我想", "给建议",
                "推荐", "告诉我", "问一下", "问个问题",
                "随便看看", "随便", "玩玩", "聊聊天", "说说话"
            ]
            question_lower = question.lower()
            for kw in chat_keywords:
                if kw in question_lower:
                    return "general_chat"
            return "invalid_or_unclear"

        question_lower = question.lower()

        data_keywords = [
            "分析", "统计", "汇总", "趋势", "销售", "销售额", "订单",
            "图表", "图像", "可视化", "柱状图", "折线图", "饼图",
            "地区", "月份", "商品", "类别", "利润", "数量", "成本",
            "看看", "帮我看", "看一下", "分析一下", "帮我分析",
            "不同", "最高", "最低", "最大", "最小", "前10", "排名",
            "找出", "查询", "计算", "对比", "比较"
        ]

        chat_keywords = [
            "你是谁", "你好", "早上好", "下午好", "晚上好", "嗨", "嘿",
            "介绍一下", "解释一下", "什么是", "什么叫",
            "帮我写", "项目介绍", "系统介绍", "怎么样", "如何", "怎么",
            "星期", "今天", "明天", "昨天", "天气", "时间", "日期",
            "为什么", "原因", "怎么办", "干啥", "做啥",
            "叫什么", "名字", "是谁", "有用吗", "靠谱吗",
            "笑话", "幽默", "搞笑", "故事", "新闻", "八卦",
            "电影", "音乐", "游戏", "体育", "足球", "篮球",
            "美食", "旅游", "健康", "减肥", "健身",
            "股票", "基金", "理财", "加密货币", "比特币",
            "翻译", "英文", "英语", "学英语", "学编程",
            "写代码", "写诗", "写作文", "帮我想", "给建议",
            "推荐", "告诉我", "问一下", "问个问题",
            "随便看看", "随便", "玩玩", "聊聊天", "说说话",
            "等于几", "是多少", "怎么算", "帮我算", "计算",
            "介绍一下", "说一说", "讲讲", "聊聊"
        ]

        for col in self.fields_info.get('columns', []):
            if col.lower() in question_lower:
                return "data_analysis"

        for kw in data_keywords:
            if kw in question_lower:
                return "data_analysis"

        for kw in chat_keywords:
            if kw in question_lower:
                return "general_chat"

        if len(question) < 20:
            return "general_chat"

        return "invalid_or_unclear"

    def _build_unified_result(self, **kwargs) -> Dict[str, Any]:
        return {
            "task_type": kwargs.get("task_type", "invalid_or_unclear"),
            "trace_id": kwargs.get("trace_id", ""),
            "user_question": kwargs.get("user_question", ""),
            "final_answer": kwargs.get("final_answer", ""),
            "summary": kwargs.get("summary", ""),
            "intent": kwargs.get("intent", ""),
            "filters": kwargs.get("filters", {}),
            "group_by": kwargs.get("group_by", ""),
            "metric": kwargs.get("metric", ""),
            "chart_type": kwargs.get("chart_type", ""),
            "data_table": kwargs.get("data_table", None),
            "charts": kwargs.get("charts", []),
            "steps": kwargs.get("steps", []),
            "tool_results": kwargs.get("tool_results", {}),
            "risk_level": kwargs.get("risk_level", "低风险"),
            "status": kwargs.get("status", "success"),
            "error": kwargs.get("error", "")
        }

    def process_user_question(self, user_question: str, mode: str = 'react', chart_type: str = 'auto') -> Dict[str, Any]:
        if self.df is None and mode != 'rule':
            self._init_llm_client()
            has_api_key = (self.llm_client is not None)

            if has_api_key:
                trace_id = self.trace_logger.start_trace(
                    user_question=user_question,
                    analysis_plan='通用问答',
                    risk_level='low'
                )
                try:
                    system_prompt = "你是一个友好的AI助手。请直接回答用户的问题。"
                    response = self.llm_client.generate(
                        prompt=user_question,
                        system_prompt=system_prompt
                    )
                    self.trace_logger.end_trace(status='completed')
                    return self._build_unified_result(
                        task_type="general_chat",
                        trace_id=trace_id,
                        user_question=user_question,
                        final_answer=response,
                        summary=response[:200] + '...' if len(response) > 200 else response,
                        status="success"
                    )
                except Exception as e:
                    self.trace_logger.end_trace(status='failed')
                    return self._build_unified_result(
                        task_type="general_chat",
                        trace_id=trace_id or "",
                        user_question=user_question,
                        final_answer="抱歉，AI服务暂时不可用。",
                        summary="AI服务调用失败",
                        status="error",
                        error=str(e)
                    )
            else:
                return self._build_unified_result(
                    task_type="general_chat",
                    trace_id="",
                    user_question=user_question,
                    final_answer="我是一个智能数据分析助手，可以帮助你完成数据上传、统计分析、图表生成和报告导出。请先上传数据文件。",
                    summary="无数据状态下的通用问答",
                    status="success"
                )

        task_type = self.classify_question(user_question)

        if task_type == "general_chat":
            return self._handle_general_chat(user_question, mode)
        elif task_type == "data_analysis":
            return self._handle_data_analysis(user_question, mode, chart_type)
        else:
            return self._handle_invalid_question(user_question)

    def _handle_general_chat(self, user_question: str, mode: str) -> Dict[str, Any]:
        self._init_llm_client()
        has_api_key = (self.llm_client is not None)

        trace_id = self.trace_logger.start_trace(
            user_question=user_question,
            analysis_plan='通用问答',
            risk_level='low'
        )

        if has_api_key:
            try:
                system_prompt = """你是一个智能助手，可以回答用户的各种问题。

回答规则：
1. 如果用户问的是日期、时间等实时信息，请诚实回答：如果你不确定当前准确日期，请说"我无法获取实时日期信息，建议您查看手机或电脑上的日期"
2. 回答要简洁、准确、友好
3. 不知道的事情不要编造，直接说不知道
4. 不要主动介绍系统功能，除非用户明确询问"""

                response = self.llm_client.generate(
                    prompt=user_question,
                    system_prompt=system_prompt
                )
                self.trace_logger.end_trace(status='completed')
                steps = [{
                    "step": 1,
                    "action": "general_chat",
                    "thought": "通用问答完成",
                    "observation": "AI直接回答用户问题",
                    "status": "completed",
                    "duration_ms": 0
                }]
                return self._build_unified_result(
                    task_type="general_chat",
                    trace_id=trace_id,
                    user_question=user_question,
                    final_answer=response,
                    summary=response[:200] + '...' if len(response) > 200 else response,
                    steps=steps,
                    status="success"
                )
            except Exception as e:
                self.trace_logger.end_trace(status='failed')
                fallback = "抱歉，AI服务暂时不可用。请检查API配置或网络连接。"
                return self._build_unified_result(
                    task_type="general_chat",
                    trace_id=trace_id,
                    user_question=user_question,
                    final_answer=fallback,
                    summary="AI服务调用失败",
                    status="error",
                    error=str(e)
                )
        else:
            self.trace_logger.end_trace(status='completed')
            fallback_answer = "您好！当前无法获取AI回答。请在左侧配置API Key或检查网络连接。"

            steps = [{
                "step": 1,
                "action": "general_chat",
                "thought": "规则模式通用问答",
                "observation": "返回平台介绍",
                "status": "completed",
                "duration_ms": 0
            }]
            return self._build_unified_result(
                task_type="general_chat",
                trace_id=trace_id,
                user_question=user_question,
                final_answer=fallback_answer,
                summary="无API Key，返回提示",
                steps=steps,
                status="success"
            )

    def _handle_data_analysis(self, user_question: str, mode: str, chart_type: str) -> Dict[str, Any]:
        if mode in ['react', 'qwen'] and self.llm_config.get('api_key'):
            return self.run_react_agent(user_question, chart_type=chart_type)
        else:
            return self._rule_based_analysis(user_question, chart_type)

    def _handle_invalid_question(self, user_question: str) -> Dict[str, Any]:
        trace_id = self.trace_logger.start_trace(
            user_question=user_question,
            analysis_plan='无效问题',
            risk_level='low'
        )
        self.trace_logger.end_trace(status='completed')

        steps = [{
            "step": 1,
            "action": "classify_question",
            "thought": "问题分类：invalid_or_unclear",
            "observation": "问题不明确或与数据分析无关",
            "status": "completed",
            "duration_ms": 0
        }]

        invalid_answer = (
            "您的问题不够明确。为了帮助您进行数据分析，请补充以下信息之一：\n\n"
            "• 想分析的字段（如：地区、销售额、商品类别）\n"
            "• 分析范围（如：华南地区、北京区域）\n"
            "• 分析目标（如：最高销售额、趋势变化）\n\n"
            '例如，您可以这样问：\n'
            '- "分析华北地区的销售情况"\n'
            '- "哪些商品销售额最高"\n'
            '- "按月份统计收入趋势"'
        )

        return self._build_unified_result(
            task_type="invalid_or_unclear",
            trace_id=trace_id,
            user_question=user_question,
            final_answer=invalid_answer,
            summary="问题不明确，需要用户补充信息",
            steps=steps,
            status="success"
        )

    def _rule_based_analysis(self, user_question: str, chart_type: str) -> Dict[str, Any]:
        question_lower = user_question.lower()

        trace_id = self.trace_logger.start_trace(
            user_question=user_question,
            analysis_plan='规则匹配分析',
            risk_level='low'
        )

        trace_steps = []
        filtered_df = self.df
        chart_paths = []
        chart_error = None
        final_answer = ""
        summary = ""
        data_table = None
        analysis_results = None

        region_keywords = ['华南', '华东', '华北', '华中', '西南', '东北', '西北', '北京', '上海', '广州', '深圳', '杭州', '南京', '武汉', '成都', '重庆', '西安', '天津']
        value_keywords = ['销售', '销售额', '业绩', '利润', '收入', '订单', '数量', '成本']
        chart_keywords = ['图', '图表', '图像', '可视化', '柱状图', '折线图', '饼图', '散点图', '生成图']
        general_analysis_keywords = ['分析', '看看', '帮我看', '看一下', '分析一下', '帮我分析', '统计', '汇总', '数据']

        need_chart = (chart_type != 'auto') or any(kw in question_lower for kw in chart_keywords)

        actual_chart_type = 'bar'
        if chart_type and chart_type != 'auto':
            actual_chart_type = chart_type
        elif '折线' in question_lower:
            actual_chart_type = 'line'
        elif '饼' in question_lower:
            actual_chart_type = 'pie'
        elif '散点' in question_lower:
            actual_chart_type = 'scatter'

        filter_col = None
        filter_value = None
        for col in self.fields_info.get('categorical_columns', []):
            col_lower = col.lower()
            for region in region_keywords:
                if region.lower() in question_lower or region in user_question:
                    if col_lower in question_lower or col.lower() in ['地区', '区域', '城市', '省份', '城市名称', '地区名称']:
                        filter_col = col
                        filter_value = region
                        break
            if filter_col:
                break

        if filter_col and filter_value:
            trace_steps.append({
                'thought': f'识别到筛选条件：{filter_col}={filter_value}',
                'action': 'filter',
                'status': 'completed',
                'duration_ms': 0
            })
            filtered_df = self.df[self.df[filter_col].astype(str).str.contains(filter_value, na=False)]
            if len(filtered_df) == 0:
                filtered_df = self.df[self.df[filter_col] == filter_value]
            trace_steps.append({
                'thought': f'筛选后数据量：{len(filtered_df)} / {len(self.df)} 条',
                'action': 'filter_result',
                'status': 'completed',
                'duration_ms': 0
            })

        numeric_cols = self.fields_info.get('numeric_columns', [])
        value_col = None
        for kw in value_keywords:
            for col in numeric_cols:
                if kw in col.lower() or col.lower() in kw:
                    value_col = col
                    break
            if value_col:
                break
        if not value_col and numeric_cols:
            value_col = numeric_cols[0]

        group_by_cols = []
        for col in self.fields_info.get('categorical_columns', []):
            col_lower = col.lower()
            if col_lower in ['月份', '月份', '商品类别', '商品', '产品', '类别', '区域', '城市', '地区', '年份', '年度', '季度']:
                if col != filter_col:
                    group_by_cols.append(col)
                    break
        if not group_by_cols and self.fields_info.get('categorical_columns'):
            for col in self.fields_info['categorical_columns']:
                if col != filter_col:
                    group_by_cols.append(col)
                    break

        if value_col and group_by_cols:
            group_col = group_by_cols[0]

            trace_steps.append({
                'thought': f'识别数值字段：{value_col}，分组字段：{group_col}',
                'action': 'groupby_sum',
                'status': 'completed',
                'duration_ms': 0
            })

            try:
                grouped = filtered_df.groupby(group_col)[value_col].sum().reset_index()
                grouped.columns = [group_col, value_col]
                analysis_results = grouped.copy()

                trace_steps.append({
                    'thought': f'分组统计完成，共 {len(grouped)} 个分组',
                    'action': 'groupby_result',
                    'status': 'completed',
                    'duration_ms': 0
                })

                total = grouped[value_col].sum()
                max_idx = grouped[value_col].idxmax()
                min_idx = grouped[value_col].idxmin()
                max_val = grouped.loc[max_idx, value_col]
                min_val = grouped.loc[min_idx, value_col]
                max_group = grouped.loc[max_idx, group_col]
                min_group = grouped.loc[min_idx, group_col]

                data_table = grouped

                region_info = f"针对{filter_value}地区" if filter_value else "全量数据"
                final_answer = f"""本次分析{region_info}销售数据展开。

{group_col}销售统计结果如下：
- **销售总额**：{total:,.2f}
- **最高销售**：{max_group}（{max_val:,.2f}）
- **最低销售**：{min_group}（{min_val:,.2f}）
- **差异**：最高与最低相差 {(max_val - min_val):,.2f}（{(max_val / min_val * 100) if min_val != 0 else 0:.1f}%）

"""

                if len(filtered_df) > 0:
                    avg_per_record = total / len(filtered_df) if len(filtered_df) > 0 else 0
                    final_answer += f"- **平均每单销售额**：{avg_per_record:,.2f}\n"

                final_answer += "详细统计数据已展示在下方表格中。"

                if need_chart:
                    trace_steps.append({
                        'thought': f'根据用户需求，生成图表',
                        'action': 'generate_chart',
                        'status': 'completed',
                        'duration_ms': 0
                    })

                    try:
                        chart_result = self.chart_generator.generate_chart(
                            chart_type=actual_chart_type,
                            data=grouped,
                            title=f'{region_info}{group_col}销售统计',
                            x_label=group_col,
                            y_label=value_col
                        )
                        chart_path, chart_msg = chart_result if chart_result else (None, None)
                        if chart_path:
                            chart_paths.append({
                                'path': chart_path,
                                'type': actual_chart_type,
                                'title': f'{region_info}{group_col}销售统计'
                            })
                        else:
                            chart_error = chart_msg or '图表生成返回结果为空'
                    except Exception as e:
                        chart_error = f'图表生成失败: {str(e)}'
                        trace_steps.append({
                            'thought': f'图表生成失败: {str(e)}',
                            'action': 'chart_error',
                            'status': 'failed',
                            'duration_ms': 0
                        })
            except Exception as e:
                trace_steps.append({
                    'thought': f'分组统计失败: {str(e)}，回退到数据画像',
                    'action': 'fallback_profile',
                    'status': 'failed',
                    'duration_ms': 0
                })
                profile_result = self.tool_registry['data_profile']['callable']({})
                analysis_results = profile_result.get('data')
                data_table = analysis_results
                final_answer = self._generate_profile_conclusion(analysis_results)
        else:
            has_general_keyword = any(kw in question_lower for kw in general_analysis_keywords)

            if has_general_keyword and numeric_cols and group_by_cols:
                trace_steps.append({
                    'thought': f'根据通用分析关键词，使用数值字段和分组字段进行分析',
                    'action': 'general_analysis',
                    'status': 'completed',
                    'duration_ms': 0
                })

                value_col = numeric_cols[0]
                group_col = group_by_cols[0]

                try:
                    grouped = filtered_df.groupby(group_col)[value_col].sum().reset_index()
                    grouped.columns = [group_col, value_col]
                    analysis_results = grouped.copy()

                    trace_steps.append({
                        'thought': f'分组统计完成，共 {len(grouped)} 个分组',
                        'action': 'groupby_result',
                        'status': 'completed',
                        'duration_ms': 0
                    })

                    total = grouped[value_col].sum()
                    max_idx = grouped[value_col].idxmax()
                    min_idx = grouped[value_col].idxmin()
                    max_val = grouped[value_col].max()
                    min_val = grouped[value_col].min()
                    max_group = grouped.loc[max_idx, group_col]
                    min_group = grouped.loc[min_idx, group_col]

                    data_table = grouped

                    region_info = f"针对{filter_value}地区" if filter_value else "全量数据"
                    final_answer = f"""本次分析{region_info}数据。

按{group_col}统计{value_col}的结果如下：
- **总计**：{total:,.2f}
- **最高**：{max_group}（{max_val:,.2f}）
- **最低**：{min_group}（{min_val:,.2f}）
- **平均**：{total/len(grouped) if len(grouped) > 0 else 0:,.2f}

详细统计数据已展示在下方表格中。"""

                    if need_chart:
                        try:
                            chart_result = self.chart_generator.generate_chart(
                                chart_type=actual_chart_type,
                                data=grouped,
                                title=f'{region_info}{group_col}统计',
                                x_label=group_col,
                                y_label=value_col
                            )
                            chart_path, chart_msg = chart_result if chart_result else (None, None)
                            if chart_path:
                                chart_paths.append({
                                    'path': chart_path,
                                    'type': actual_chart_type,
                                    'title': f'{region_info}{group_col}统计'
                                })
                            else:
                                chart_error = chart_msg or '图表生成失败'
                        except Exception as e:
                            chart_error = f'图表生成失败: {str(e)}'
                except Exception as e:
                    trace_steps.append({
                        'thought': f'分析失败: {str(e)}',
                        'action': 'analysis_error',
                        'status': 'failed',
                        'duration_ms': 0
                    })
                    profile_result = self.tool_registry['data_profile']['callable']({})
                    analysis_results = profile_result.get('data')
                    data_table = analysis_results
                    final_answer = self._generate_profile_conclusion(analysis_results)
            else:
                trace_steps.append({
                    'thought': '未识别到明确分析意图，回退到数据画像',
                    'action': 'data_profile',
                    'status': 'completed',
                    'duration_ms': 0
                })
                profile_result = self.tool_registry['data_profile']['callable']({})
                analysis_results = profile_result.get('data')
                data_table = analysis_results
                final_answer = self._generate_profile_conclusion(analysis_results)

                if need_chart:
                    try:
                        numeric_cols = self.fields_info.get('numeric_columns', [])
                        if numeric_cols:
                            sample_data = filtered_df[numeric_cols[:2]].head(50)
                            chart_result = self.chart_generator.generate_chart(
                                chart_type=actual_chart_type,
                                data=sample_data,
                                title='数据分布图',
                                x_label=numeric_cols[0] if len(numeric_cols) > 0 else None,
                                y_label=numeric_cols[1] if len(numeric_cols) > 1 else numeric_cols[0] if numeric_cols else None
                            )
                            chart_path, chart_msg = chart_result if chart_result else (None, None)
                            if chart_path:
                                chart_paths.append({
                                    'path': chart_path,
                                    'type': actual_chart_type,
                                    'title': '数据分布图'
                                })
                            else:
                                chart_error = chart_msg or '图表生成失败'
                    except Exception as e:
                        chart_error = f'图表生成失败: {str(e)}'

        summary = final_answer[:200] + "..." if len(final_answer) > 200 else final_answer

        trace_steps.append({
            'thought': f'分析完成。生成图表 {len(chart_paths)} 个' + (f'，图表错误: {chart_error}' if chart_error else ''),
            'action': 'final_answer',
            'status': 'completed',
            'duration_ms': 0
        })

        for i, step in enumerate(trace_steps):
            step['step'] = i + 1
            step['observation'] = step.get('thought', '')
            step['need_review'] = False

        self.trace_logger.add_step({
            'thought': '规则匹配分析完成',
            'action': 'rule_based_analysis',
            'action_input': {'question': user_question, 'chart_type': chart_type},
            'observation': summary,
            'risk_level': 'low',
            'need_human_review': False,
            'status': 'completed',
            'duration_ms': 0
        })

        self.trace_logger.end_trace(status='completed')

        return self._build_unified_result(
            task_type="data_analysis",
            trace_id=trace_id,
            user_question=user_question,
            final_answer=final_answer,
            summary=summary,
            data_table=data_table,
            charts=chart_paths,
            steps=trace_steps,
            intent="rule_based_analysis",
            filters={filter_col: filter_value} if filter_col and filter_value else {},
            group_by=group_by_cols[0] if group_by_cols else "",
            metric=value_col if value_col else "",
            chart_type=actual_chart_type,
            tool_results={"analysis_results": analysis_results},
            risk_level="低风险",
            status="success",
            error=chart_error if chart_error else ""
        )

    def _generate_profile_conclusion(self, profile_data) -> str:
        if profile_data is None:
            return "数据画像分析完成，但未获取到有效数据。"

        if isinstance(profile_data, dict):
            total_rows = profile_data.get('total_rows', 0)
            total_cols = profile_data.get('total_columns', 0)
            numeric_cols = profile_data.get('numeric_columns', [])
            categorical_cols = profile_data.get('categorical_columns', [])

            return f"""数据画像分析完成：

- **数据规模**：共 {total_rows:,} 行，{total_cols} 列
- **数值字段**：{len(numeric_cols)} 个（{', '.join(numeric_cols[:5])}{'...' if len(numeric_cols) > 5 else ''}）
- **类别字段**：{len(categorical_cols)} 个（{', '.join(categorical_cols[:5])}{'...' if len(categorical_cols) > 5 else ''}）

详细统计数据请查看下方表格。"""

        elif isinstance(profile_data, pd.DataFrame):
            rows = len(profile_data)
            cols = len(profile_data.columns)
            return f"数据画像分析完成：共 {rows:,} 行，{cols} 列。详细数据请查看下方表格。"

        return "数据画像分析完成。"

    def _generate_conclusion_from_data(self, query: str, last_result_data, last_action: str, observation_history: list) -> Tuple[str, Any]:
        if last_result_data is None:
            if observation_history:
                observations = [obs[1] for obs in observation_history if obs[1]]
                if observations:
                    return f"""根据分析结果，本次分析主要发现如下：

- 分析共执行 {len(observation_history)} 个步骤
- 主要观察：{"；".join(observations[:3])}

详细数据请查看下方统计表格。""", None
            return f"""分析完成，共执行 {len(observation_history)} 个步骤。
未获取到详细分析数据，请查看下方统计结果。""", None

        data = last_result_data.get('data') if isinstance(last_result_data, dict) else last_result_data

        if isinstance(data, pd.DataFrame) and not data.empty:
            numeric_cols = data.select_dtypes(include=['number']).columns.tolist()

            if numeric_cols:
                value_col = numeric_cols[0]
                total = data[value_col].sum()
                max_idx = data[value_col].idxmax()
                min_idx = data[value_col].idxmin()
                max_val = data[value_col].max()
                min_val = data[value_col].min()

                first_col = data.columns[0]
                max_group = data.loc[max_idx, first_col] if first_col in data.columns else str(max_idx)
                min_group = data.loc[min_idx, first_col] if first_col in data.columns else str(min_idx)

                region_info = ""
                region_keywords = ['华南', '华东', '华北', '华中', '西南', '东北', '西北', '北京', '上海', '广州', '深圳']
                for region in region_keywords:
                    if region in query:
                        region_info = f"针对{region}地区"
                        break

                conclusion = f"""本次分析{region_info}结果如下：

- **统计记录**：共 {len(data)} 个类别
- **数值总和**：{total:,.2f}
- **最高值**：{max_group}（{max_val:,.2f}）
- **最低值**：{min_group}（{min_val:,.2f}）
- **差异**：最高与最低相差 {(max_val - min_val):,.2f}（{(max_val / min_val * 100) if min_val != 0 else 0:.1f}%）"""

                if len(data) > 1:
                    avg = total / len(data)
                    conclusion += f"\n- **平均值**：{avg:,.2f}"

                conclusion += "\n\n详细统计数据已展示在下方表格中。"

                return conclusion, data

        if isinstance(last_result_data, dict):
            summary = last_result_data.get('summary', '')
            if summary:
                return f"""本次分析结论：

{summary}

详细数据请查看下方统计结果。""", last_result_data.get('data')

        return f"""分析完成，共执行 {len(observation_history)} 个步骤。
主要操作：{last_action if last_action else '数据处理'}
详细数据请查看下方统计结果。""", data if isinstance(data, pd.DataFrame) else None

    def _extract_field(self, question: str, fields: List[str]) -> Optional[str]:
        question_lower = question.lower()
        for field in fields:
            if field.lower() in question_lower:
                return field
        return fields[0] if fields else None

    def _find_date_column(self) -> Optional[str]:
        for col in self.fields_info.get('date_columns', []):
            return col
        for col in self.df.columns:
            if 'date' in col.lower() or 'time' in col.lower() or '月' in col or '年' in col:
                return col
        return None

    def _execute_trend_analysis(self, date_col: str, value_col: str) -> Optional[pd.DataFrame]:
        if 'trend_analysis' in self.tool_registry:
            result = self.tool_registry['trend_analysis']['callable']({
                'date_col': date_col,
                'value': value_col
            })
            return result.get('data')
        return None

    def get_trace_summary(self):
        return self.trace_logger.get_trace_summary()

    def get_trace_details(self, trace_id=None):
        return self.trace_logger.get_trace_details(trace_id)
