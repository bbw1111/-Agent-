import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional, Callable


def create_pandas_tools(df=None, analysis_engine=None) -> Dict[str, Callable]:
    if df is None:
        df = pd.DataFrame()

    tools = {}

    def data_profile_tool(params: Dict = None) -> Dict[str, Any]:
        if df is None or df.empty:
            return {'error': '数据未加载', 'data': None}

        profile = {
            'row_count': len(df),
            'column_count': len(df.columns),
            'columns': list(df.columns),
            'numeric_columns': list(df.select_dtypes(include=['number']).columns),
            'categorical_columns': list(df.select_dtypes(include=['object', 'category']).columns),
            'date_columns': list(df.select_dtypes(include=['datetime']).columns),
            'missing_values': df.isnull().sum().to_dict(),
            'memory_usage_mb': round(df.memory_usage(deep=True).sum() / 1024 / 1024, 2)
        }

        numeric_cols = df.select_dtypes(include=['number']).columns
        if len(numeric_cols) > 0:
            profile['numeric_summary'] = df[numeric_cols].describe().to_dict()

        return {'data': profile, 'summary': f'数据画像生成完成：共{len(df)}行，{len(df.columns)}列'}

    tools['data_profile'] = {
        'name': 'data_profile',
        'description': '生成数据画像，了解数据基本信息和字段统计特征',
        'args_schema': {
            'type': 'object',
            'properties': {},
            'required': []
        },
        'callable': data_profile_tool
    }

    def schema_check_tool(params: Dict = None) -> Dict[str, Any]:
        if df is None:
            return {'error': '数据未加载', 'data': None}

        schema = {
            'columns': list(df.columns),
            'dtypes': {col: str(dtype) for col, dtype in df.dtypes.items()},
            'row_count': len(df),
            'column_count': len(df.columns),
            'numeric_columns': list(df.select_dtypes(include=['number']).columns),
            'categorical_columns': list(df.select_dtypes(include=['object', 'category']).columns)
        }

        return {'data': schema, 'summary': f'字段结构检查完成：{len(df.columns)}个字段'}

    tools['schema_check'] = {
        'name': 'schema_check',
        'description': '检查数据字段结构，返回字段名、类型、缺失值等信息',
        'args_schema': {
            'type': 'object',
            'properties': {},
            'required': []
        },
        'callable': schema_check_tool
    }

    def groupby_sum_tool(params: Dict) -> Dict[str, Any]:
        if df is None:
            return {'error': '数据未加载', 'data': None}

        group_col = params.get('group_by')
        value_col = params.get('value')

        if not group_col or not value_col:
            return {'error': '缺少必需参数: group_by, value', 'data': None}

        if group_col not in df.columns:
            return {'error': f'字段 {group_col} 不存在', 'data': None}
        if value_col not in df.columns:
            return {'error': f'字段 {value_col} 不存在', 'data': None}

        try:
            result = df.groupby(group_col)[value_col].sum().reset_index()
            result.columns = [group_col, f'{value_col}_sum']
            return {
                'data': result.to_dict(),
                'summary': f'按 {group_col} 分组求和完成，最高值: {result.iloc[:, 1].max():.2f}'
            }
        except Exception as e:
            return {'error': str(e), 'data': None}

    tools['groupby_sum'] = {
        'name': 'groupby_sum',
        'description': '按类别字段分组计算数值字段的总和',
        'args_schema': {
            'type': 'object',
            'properties': {
                'group_by': {'type': 'string', 'description': '分组字段名'},
                'value': {'type': 'string', 'description': '要汇总的数值字段名'}
            },
            'required': ['group_by', 'value']
        },
        'callable': groupby_sum_tool
    }

    def groupby_count_tool(params: Dict) -> Dict[str, Any]:
        if df is None:
            return {'error': '数据未加载', 'data': None}

        group_col = params.get('group_by')
        value_col = params.get('value', group_col)

        if not group_col:
            return {'error': '缺少必需参数: group_by', 'data': None}

        if group_col not in df.columns:
            return {'error': f'字段 {group_col} 不存在', 'data': None}

        try:
            result = df.groupby(group_col)[value_col].count().reset_index()
            result.columns = [group_col, f'{value_col}_count']
            return {
                'data': result.to_dict(),
                'summary': f'按 {group_col} 分组计数完成，共 {len(result)} 个分组'
            }
        except Exception as e:
            return {'error': str(e), 'data': None}

    tools['groupby_count'] = {
        'name': 'groupby_count',
        'description': '按类别字段分组计数',
        'args_schema': {
            'type': 'object',
            'properties': {
                'group_by': {'type': 'string', 'description': '分组字段名'},
                'value': {'type': 'string', 'description': '计数的字段名'}
            },
            'required': ['group_by']
        },
        'callable': groupby_count_tool
    }

    def groupby_mean_tool(params: Dict) -> Dict[str, Any]:
        if df is None:
            return {'error': '数据未加载', 'data': None}

        group_col = params.get('group_by')
        value_col = params.get('value')

        if not group_col or not value_col:
            return {'error': '缺少必需参数: group_by, value', 'data': None}

        if group_col not in df.columns or value_col not in df.columns:
            return {'error': '指定的字段不存在', 'data': None}

        try:
            result = df.groupby(group_col)[value_col].mean().reset_index()
            result.columns = [group_col, f'{value_col}_mean']
            return {
                'data': result.to_dict(),
                'summary': f'按 {group_col} 分组平均完成'
            }
        except Exception as e:
            return {'error': str(e), 'data': None}

    tools['groupby_mean'] = {
        'name': 'groupby_mean',
        'description': '按类别字段分组计算数值字段的平均值',
        'args_schema': {
            'type': 'object',
            'properties': {
                'group_by': {'type': 'string', 'description': '分组字段名'},
                'value': {'type': 'string', 'description': '要计算平均的数值字段名'}
            },
            'required': ['group_by', 'value']
        },
        'callable': groupby_mean_tool
    }

    def topn_analysis_tool(params: Dict) -> Dict[str, Any]:
        if df is None:
            return {'error': '数据未加载', 'data': None}

        value_col = params.get('value')
        n = params.get('n', 10)
        group_col = params.get('group_by')

        if not value_col:
            return {'error': '缺少必需参数: value', 'data': None}

        if value_col not in df.columns:
            return {'error': f'字段 {value_col} 不存在', 'data': None}

        try:
            if group_col and group_col in df.columns:
                result = df.groupby(group_col)[value_col].sum().sort_values(ascending=False).head(n).reset_index()
                result.columns = [group_col, value_col]
            else:
                if df[value_col].dtype == 'object':
                    result = df[value_col].value_counts().head(n).reset_index()
                    result.columns = [value_col, 'count']
                else:
                    result = df.nlargest(n, value_col).reset_index(drop=True)

            return {
                'data': result.to_dict(),
                'summary': f'Top {n} 分析完成，最高值: {result.iloc[:, 1].max() if len(result) > 0 else 0:.2f}'
            }
        except Exception as e:
            return {'error': str(e), 'data': None}

    tools['topn_analysis'] = {
        'name': 'topn_analysis',
        'description': '找出排名前N的数据',
        'args_schema': {
            'type': 'object',
            'properties': {
                'value': {'type': 'string', 'description': '排序依据的数值字段'},
                'n': {'type': 'integer', 'description': '返回前N条', 'default': 10},
                'group_by': {'type': 'string', 'description': '可选，按某字段分组后再排序'}
            },
            'required': ['value']
        },
        'callable': topn_analysis_tool
    }

    def correlation_analysis_tool(params: Dict) -> Dict[str, Any]:
        if df is None:
            return {'error': '数据未加载', 'data': None}

        col1 = params.get('col1')
        col2 = params.get('col2')

        if not col1 or not col2:
            return {'error': '缺少必需参数: col1, col2', 'data': None}

        if col1 not in df.columns or col2 not in df.columns:
            return {'error': '指定的字段不存在', 'data': None}

        try:
            numeric_df = df[[col1, col2]].dropna()
            if len(numeric_df) < 2:
                return {'error': '数据点不足', 'data': None}

            corr = numeric_df[col1].corr(numeric_df[col2])

            interpretation = '强相关' if abs(corr) >= 0.8 else '中等相关' if abs(corr) >= 0.5 else '弱相关'
            if corr < 0:
                interpretation = '负' + interpretation
            else:
                interpretation = '正' + interpretation

            return {
                'data': {'correlation': round(corr, 4), 'interpretation': interpretation},
                'summary': f'相关性分析完成：相关系数 {corr:.4f}，{interpretation}'
            }
        except Exception as e:
            return {'error': str(e), 'data': None}

    tools['correlation_analysis'] = {
        'name': 'correlation_analysis',
        'description': '分析两个数值字段之间的相关性',
        'args_schema': {
            'type': 'object',
            'properties': {
                'col1': {'type': 'string', 'description': '第一个数值字段'},
                'col2': {'type': 'string', 'description': '第二个数值字段'}
            },
            'required': ['col1', 'col2']
        },
        'callable': correlation_analysis_tool
    }

    def describe_tool(params: Dict = None) -> Dict[str, Any]:
        if df is None:
            return {'error': '数据未加载', 'data': None}

        columns = params.get('columns') if params else None

        try:
            if columns:
                cols = [c for c in columns if c in df.columns]
                if not cols:
                    return {'error': '指定的字段都不存在', 'data': None}
                desc = df[cols].describe()
            else:
                numeric_cols = df.select_dtypes(include=['number']).columns
                desc = df[numeric_cols].describe()

            return {
                'data': desc.to_dict(),
                'summary': f'描述性统计生成完成，共 {len(desc)} 个统计指标'
            }
        except Exception as e:
            return {'error': str(e), 'data': None}

    tools['describe'] = {
        'name': 'describe',
        'description': '生成描述性统计信息',
        'args_schema': {
            'type': 'object',
            'properties': {
                'columns': {'type': 'array', 'items': {'type': 'string'}, 'description': '要统计的字段列表'}
            }
        },
        'callable': describe_tool
    }

    def filter_tool(params: Dict) -> Dict[str, Any]:
        if df is None:
            return {'error': '数据未加载', 'data': None}

        column = params.get('column')
        operator = params.get('operator', '==')
        value = params.get('value')

        if not column or value is None:
            return {'error': '缺少必需参数: column, value', 'data': None}

        if column not in df.columns:
            return {'error': f'字段 {column} 不存在', 'data': None}

        try:
            if operator == '==':
                filtered = df[df[column] == value]
            elif operator == '!=':
                filtered = df[df[column] != value]
            elif operator == '>':
                filtered = df[df[column] > float(value)]
            elif operator == '<':
                filtered = df[df[column] < float(value)]
            elif operator == '>=':
                filtered = df[df[column] >= float(value)]
            elif operator == '<=':
                filtered = df[df[column] <= float(value)]
            elif operator == 'contains':
                filtered = df[df[column].astype(str).str.contains(str(value), na=False)]
            else:
                return {'error': f'不支持的操作符: {operator}', 'data': None}

            return {
                'data': filtered.head(100).to_dict(),
                'summary': f'筛选完成，保留 {len(filtered)} / {len(df)} 条数据'
            }
        except Exception as e:
            return {'error': str(e), 'data': None}

    tools['filter'] = {
        'name': 'filter',
        'description': '根据条件筛选数据',
        'args_schema': {
            'type': 'object',
            'properties': {
                'column': {'type': 'string', 'description': '筛选字段'},
                'operator': {'type': 'string', 'description': '操作符', 'enum': ['==', '!=', '>', '<', '>=', '<=', 'contains']},
                'value': {'type': 'string', 'description': '筛选值'}
            },
            'required': ['column', 'operator', 'value']
        },
        'callable': filter_tool
    }

    def sort_tool(params: Dict) -> Dict[str, Any]:
        if df is None:
            return {'error': '数据未加载', 'data': None}

        columns = params.get('columns', [])
        ascending = params.get('ascending', True)

        if not columns:
            return {'error': '缺少必需参数: columns', 'data': None}

        valid_cols = [c for c in columns if c in df.columns]
        if not valid_cols:
            return {'error': '指定的字段都不存在', 'data': None}

        try:
            sorted_df = df.sort_values(by=valid_cols, ascending=ascending)
            return {
                'data': sorted_df.head(100).to_dict(),
                'summary': f'排序完成，{len(sorted_df)} 条数据'
            }
        except Exception as e:
            return {'error': str(e), 'data': None}

    tools['sort'] = {
        'name': 'sort',
        'description': '对数据排序',
        'args_schema': {
            'type': 'object',
            'properties': {
                'columns': {'type': 'array', 'items': {'type': 'string'}, 'description': '排序列'},
                'ascending': {'type': 'boolean', 'description': '升序还是降序', 'default': True}
            },
            'required': ['columns']
        },
        'callable': sort_tool
    }

    return tools
