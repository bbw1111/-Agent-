import pandas as pd
from typing import Dict, Any, Callable
from datetime import datetime
import config


def create_report_tools(df=None, report_generator=None, trace_id=None) -> Dict[str, Callable]:
    if df is None:
        df = pd.DataFrame()

    tools = {}

    def generate_report_tool(params: Dict = None) -> Dict[str, Any]:
        if df is None:
            return {'error': '数据未加载', 'report_path': None}

        report_type = 'markdown'
        title = '智能数据分析报告'

        if params:
            report_type = params.get('report_type', 'markdown')
            title = params.get('title', '智能数据分析报告')

        if report_generator is None:
            return {'error': '报告生成器未初始化', 'report_path': None}

        try:
            analysis_data = {
                'title': title,
                'basic_info': {
                    'row_count': len(df),
                    'column_count': len(df.columns),
                    'file_name': 'data.csv',
                    'numeric_columns': list(df.select_dtypes(include=['number']).columns),
                    'categorical_columns': list(df.select_dtypes(include=['object', 'category']).columns)
                },
                'user_question': '数据分析',
                'summary': '',
                'final_answer': '',
                'data_table': None,
                'analysis_plan': 'ReAct分析完成',
                'analysis_results': df.describe().to_dict() if not df.empty else {},
                'react_steps': '本次分析未记录详细Agent执行步骤。',
                'chart_paths': [],
                'conclusions': ['分析完成']
            }

            if report_type == 'markdown':
                report_path, report_content = report_generator.generate_markdown_report(
                    analysis_data,
                    trace_id or 'unknown'
                )
            else:
                report_path, report_content = report_generator.generate_word_report(
                    analysis_data,
                    trace_id or 'unknown'
                )

            if report_path:
                return {
                    'report_path': report_path,
                    'report_type': report_type,
                    'summary': f'报告生成成功: {report_path}'
                }
            else:
                return {'error': report_content, 'report_path': None}

        except Exception as e:
            return {'error': str(e), 'report_path': None}

    tools['generate_report'] = {
        'name': 'generate_report',
        'description': '生成数据分析报告',
        'args_schema': {
            'type': 'object',
            'properties': {
                'report_type': {'type': 'string', 'description': '报告类型', 'enum': ['markdown', 'word'], 'default': 'markdown'},
                'title': {'type': 'string', 'description': '报告标题'}
            }
        },
        'callable': generate_report_tool
    }

    return tools
