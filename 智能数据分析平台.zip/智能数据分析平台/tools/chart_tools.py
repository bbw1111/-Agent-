import pandas as pd
from typing import Dict, Any, Callable, Optional
from pathlib import Path
import config


def create_chart_tools(df=None, chart_generator=None) -> Dict[str, Callable]:
    if df is None:
        df = pd.DataFrame()

    tools = {}

    def generate_chart_tool(params: Dict) -> Dict[str, Any]:
        if df is None or df.empty:
            return {'error': '数据未加载', 'chart_path': None}

        chart_type = params.get('chart_type', 'bar')
        title = params.get('title', '数据分析图表')
        chart_data = params.get('data')

        if chart_generator is None:
            return {'error': '图表生成器未初始化', 'chart_path': None}

        try:
            if chart_data:
                if isinstance(chart_data, dict):
                    if 'x' in chart_data and 'y' in chart_data:
                        data_for_chart = pd.DataFrame(chart_data)
                    else:
                        data_for_chart = pd.DataFrame(chart_data)
                else:
                    data_for_chart = chart_data
            else:
                numeric_cols = df.select_dtypes(include=['number']).columns
                if len(numeric_cols) > 0:
                    data_for_chart = pd.DataFrame({
                        'x': df.iloc[:, 0],
                        'y': df[numeric_cols[0]]
                    })
                else:
                    return {'error': '没有可用的数值字段生成图表', 'chart_path': None}

            chart_path, chart_msg = chart_generator.generate_chart(
                chart_type=chart_type,
                data=data_for_chart,
                title=title
            )

            if chart_path:
                return {
                    'chart_path': chart_path,
                    'chart_type': chart_type,
                    'summary': f'图表生成成功: {chart_path}'
                }
            else:
                return {'error': chart_msg, 'chart_path': None}

        except Exception as e:
            return {'error': str(e), 'chart_path': None}

    tools['generate_chart'] = {
        'name': 'generate_chart',
        'description': '生成数据可视化图表',
        'args_schema': {
            'type': 'object',
            'properties': {
                'chart_type': {'type': 'string', 'description': '图表类型', 'enum': ['bar', 'line', 'pie', 'scatter', 'histogram']},
                'title': {'type': 'string', 'description': '图表标题'},
                'data': {'type': 'object', 'description': '图表数据，x轴和y轴数据'}
            },
            'required': ['chart_type']
        },
        'callable': generate_chart_tool
    }

    return tools
