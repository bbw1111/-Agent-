import sqlite3
import json
from datetime import datetime
from pathlib import Path
from config import DATABASE_PATH, DATABASE_DIR

DATABASE_DIR.mkdir(parents=True, exist_ok=True)

def get_db_connection():
    conn = sqlite3.connect(str(DATABASE_PATH), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn

def init_database():
    schema_path = DATABASE_DIR / "schema.sql"
    conn = get_db_connection()
    with open(schema_path, 'r', encoding='utf-8') as f:
        schema_sql = f.read()
    conn.executescript(schema_sql)
    conn.commit()
    conn.close()

def save_upload_record(trace_id, file_name, file_size, row_count, column_count, columns_info):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO upload_records (trace_id, file_name, file_size, row_count, column_count, columns_info)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (trace_id, file_name, file_size, row_count, column_count, json.dumps(columns_info, ensure_ascii=False)))
    conn.commit()
    conn.close()

def save_analysis_record(trace_id, user_question, analysis_plan=None, risk_level='low', status='pending'):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO analysis_records (trace_id, user_question, analysis_plan, risk_level, status)
        VALUES (?, ?, ?, ?, ?)
    """, (trace_id, user_question, analysis_plan, risk_level, status))
    conn.commit()
    record_id = cursor.lastrowid
    conn.close()
    return record_id

def update_analysis_record(trace_id, status=None, completed_at=None):
    conn = get_db_connection()
    cursor = conn.cursor()
    if status:
        cursor.execute("UPDATE analysis_records SET status = ? WHERE trace_id = ?", (status, trace_id))
    if completed_at:
        cursor.execute("UPDATE analysis_records SET completed_at = ? WHERE trace_id = ?", (completed_at, trace_id))
    conn.commit()
    conn.close()

def save_tool_call_log(trace_id, tool_name, tool_input, tool_output=None, tool_output_summary=None, duration_ms=None, risk_level='low'):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO tool_call_logs (trace_id, tool_name, tool_input, tool_output, tool_output_summary, duration_ms, risk_level)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (trace_id, tool_name, json.dumps(tool_input, ensure_ascii=False),
          json.dumps(tool_output, ensure_ascii=False) if tool_output else None,
          tool_output_summary, duration_ms, risk_level))
    conn.commit()
    conn.close()

def save_chart_record(trace_id, chart_type, chart_title, chart_path, chart_data_summary=None):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO chart_records (trace_id, chart_type, chart_title, chart_path, chart_data_summary)
        VALUES (?, ?, ?, ?, ?)
    """, (trace_id, chart_type, chart_title, chart_path, chart_data_summary))
    conn.commit()
    conn.close()

def save_report_record(trace_id, report_type, report_path=None, report_content=None, risk_level='low', approved=False):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO report_records (trace_id, report_type, report_path, report_content, risk_level, approved)
        VALUES (?, ?, ?, ?, ?, ?)
    """, (trace_id, report_type, report_path, report_content, risk_level, approved))
    conn.commit()
    conn.close()

def get_analysis_history(limit=50):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT * FROM analysis_records
        ORDER BY created_at DESC
        LIMIT ?
    """, (limit,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def get_tool_call_logs(trace_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT * FROM tool_call_logs
        WHERE trace_id = ?
        ORDER BY created_at ASC
    """, (trace_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def get_charts_by_trace(trace_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT * FROM chart_records
        WHERE trace_id = ?
        ORDER BY created_at ASC
    """, (trace_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def get_reports_by_trace(trace_id):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT * FROM report_records
        WHERE trace_id = ?
        ORDER BY created_at ASC
    """, (trace_id,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]

def get_all_upload_records(limit=20):
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("""
        SELECT * FROM upload_records
        ORDER BY uploaded_at DESC
        LIMIT ?
    """, (limit,))
    rows = cursor.fetchall()
    conn.close()
    return [dict(row) for row in rows]
