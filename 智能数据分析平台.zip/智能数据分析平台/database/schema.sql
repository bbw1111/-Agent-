CREATE TABLE IF NOT EXISTS upload_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trace_id TEXT NOT NULL,
    file_name TEXT NOT NULL,
    file_size INTEGER,
    row_count INTEGER,
    column_count INTEGER,
    columns_info TEXT,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS analysis_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trace_id TEXT NOT NULL,
    user_question TEXT NOT NULL,
    analysis_plan TEXT,
    risk_level TEXT DEFAULT 'low',
    status TEXT DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP
);

CREATE TABLE IF NOT EXISTS tool_call_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trace_id TEXT NOT NULL,
    tool_name TEXT NOT NULL,
    tool_input TEXT,
    tool_output TEXT,
    tool_output_summary TEXT,
    duration_ms INTEGER,
    risk_level TEXT DEFAULT 'low',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS chart_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trace_id TEXT NOT NULL,
    chart_type TEXT NOT NULL,
    chart_title TEXT,
    chart_path TEXT,
    chart_data_summary TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS report_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    trace_id TEXT NOT NULL,
    report_type TEXT NOT NULL,
    report_path TEXT,
    report_content TEXT,
    risk_level TEXT DEFAULT 'low',
    approved BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_trace_id ON tool_call_logs(trace_id);
CREATE INDEX IF NOT EXISTS idx_trace_id_reports ON report_records(trace_id);
CREATE INDEX IF NOT EXISTS idx_trace_id_charts ON chart_records(trace_id);
